/*
 * Main Theme JavaScript file
*/

jQuery(document).ready( function ($) {
    'use strict';

    // Get website url
    var url =  $('meta[name=url]').attr('content');
    
    /*******************************
    METHODS
    ********************************/

    /*
     * Set progress bar
     *
     * @since   0.0.8.5 
     */
    Main.set_progress_bar = function() {

        // Bar
        let bar = '<div class="theme-send-loading theme-background-green"></div>';

        // Insert bar
        $(bar).insertAfter('.wrapper');

    };

    /*
     * Remove progress bar
     *
     * @since   0.0.8.5 
     */
    Main.remove_progress_bar = function() {

        // Remove the progress bar
        setTimeout(function () {

            $('body .theme-send-loading').remove();

        }, 1000);

    };
    
    /*
     * Rearrange the sidebar
     *
     * @since   0.0.8.5 
     */
    Main.rearrange = function() {

        // Get the sidebar
        let sidebar = $('.sidebar');

        // Get the sidebar's header
        let sidebar_header = $('.sidebar-header');   
        
        // Get the sidebar's bottom
        let sidebar_bottom = $('.sidebar-bottom');

        // Divide the screen width
        let screen_height = parseInt(sidebar.height()) / 2;

        // Set fix header sidebar height
        sidebar_header.css('height', screen_height + 'px');

        // Verify if the bottom sidebar has a height greater than screen_height
        if ( parseInt(sidebar_bottom.height()) > screen_height ) {

            // Set fix bottom sidebar height
            sidebar_bottom.css('height', screen_height + 'px');   

        }

    };

    /*
     * Display alert
     *
     * @param string cl contains the class
     * @param string msg contains the message
     * @param integer ft contains the time to display
     * @param integer lt contains the time to hide
     * 
     * @since   0.0.8.5 
     */
    Main.popup_fon = function( cl, msg, ft, lt ) {

        // Status class
        let bg_color = (cl === 'subi')?'theme-background-green':'theme-background-red';

        // Add message
        $('<div class="theme-popup-notification ' + bg_color + '"><i class="ri-notification-3-line"></i> ' + msg + '</div>').insertAfter('.wrapper');

        // Display alert
        setTimeout(function () {

            $( document ).find( '.theme-popup-notification' ).animate({opacity: '0'}, 500);

        }, ft);

        // Hide alert
        setTimeout(function () {

            $( document ).find( '.theme-popup-notification' ).remove();

        }, lt);

    };

    /*
     * Display pagination
     *
     * @param string id contains the location
     * @param integer total contains the number of items
     * @param integer limit contains the limit
     * 
     * @since   0.0.8.5  
     */
    Main.show_pagination = function( id, total, limit ) {
        
        // Empty pagination
        $( id + ' .theme-pagination' ).empty();

        // Set limit
        limit = limit?limit:10;
        
        // Verify if page is not 1
        if ( parseInt(Main.pagination.page) > 1 ) {
            
            // Get previous
            var previous = parseInt(Main.pagination.page) - 1;

            // Set link
            var pages = '<li class="page-item">'
                            + '<a href="#" class="page-link" data-page="' + previous + '">'
                                + '<i class="ri-arrow-left-s-line"></i>'
                            + '</a>'
                        + '</li>';
            
        } else {
            
            // Set disabled link
            var pages = '<li class="page-item disabled">'
                            + '<a href="#" class="page-link" href="#" tabindex="-1">'
                                + '<i class="ri-arrow-left-s-line"></i>'
                            + '</a>'
                        + '</li>';
            
        }
        
        // Count pages
        var tot = parseInt(total) / limit;
        tot = Math.ceil(tot) + 1;
        
        // Calculate start page
        var from = (parseInt(Main.pagination.page) > 2) ? parseInt(Main.pagination.page) - 2 : 1;
        
        // List all pages
        for ( var p = from; p < parseInt(tot); p++ ) {
            
            // Verify if p is equal to current page
            if ( p === parseInt(Main.pagination.page) ) {
                
                // Add current page
                pages += '<li class="page-item active">'
                            + '<a href="#" class="page-link" data-page="' + p + '">'
                                + p
                            + '</a>'
                        + '</li>';
                
            } else if ( (p < parseInt(Main.pagination.page) + 3) && (p > parseInt(Main.pagination.page) - 3) ) {
                
                // Add page number
                pages += '<li class="page-item">'
                            + '<a href="#" class="page-link" data-page="' + p + '">'
                                + p
                            + '</a>'
                        + '</li>';
                
            } else if ( (p < 6) && (Math.round(tot) > 5) && ((parseInt(Main.pagination.page) === 1) || (parseInt(Main.pagination.page) === 2)) ) {
                
                // Add page number
                pages += '<li class="page-item">'
                            + '<a href="#" class="page-link" data-page="' + p + '">'
                                + p
                            + '</a>'
                        + '</li>';
                
            } else {
                
                break;
                
            }
            
        }
        
        // Verify if current page is 1
        if (p === 1) {
            
            // Add current page
            pages += '<li class="page-item active">'
                        + '<a href="#" class="page-link" data-page="' + p + '">'
                            + p
                        + '</a>'
                    + '</li>';
            
        }
        
        // Set the next page
        var next = parseInt( Main.pagination.page );

        // Increase the next
        next++;
        
        // Verify if next page should be displayed
        if (next < Math.round(tot)) {

            // Add next page
            pages += '<li class="page-item">'
                        + '<a href="#" class="page-link" data-page="' + next + '">'
                            + '<i class="ri-arrow-right-s-line"></i>'
                        + '</a>'
                    + '</li>';
            
            // Display pagination
            $( id + ' .theme-pagination' ).html( pages );
            
        } else {

            // Add next page
            pages += '<li class="page-item disabled">'
                        + '<a href="#" class="page-link" data-page="' + next + '">'
                            + '<i class="ri-arrow-right-s-line"></i>'
                        + '</a>'
                    + '</li>';
            
            // Display pagination
            $( id + ' .theme-pagination' ).html( pages );
            
        }
        
    };

    /*
     * Calculate time between two dates
     *
     * @since   0.0.8.5 
     */
    Main.calculate_time = function( from, to ) {
        'use strict';

        // Set calculation time
        var calculate = to - from;

        // Set after variable
        var after = '';

        // Set before variable 
        var before = ' ' + Main.translation.theme_ago;

        // Define calc variable
        var calc;

        // Verify if time is older than now
        if ( calculate < 0 ) {

            // Set absolute value of a calculated time
            calculate = Math.abs(calculate);

            // Set icon
            after = '';

            // Empty before
            before = '';

        }

        // Calculate time
        if ( calculate < 60 ) {

            return after + Main.translation.theme_just_now;

        } else if ( calculate < 3600 ) {

            calc = calculate / 60;
            calc = Math.round(calc);
            return after + calc + ' ' + Main.translation.theme_minutes + before;

        } else if ( calculate < 86400 ) {

            calc = calculate / 3600;
            calc = Math.round(calc);
            return after + calc + ' ' + Main.translation.theme_hours + before;

        } else if ( calculate >= 86400 ) {

            calc = calculate / 86400;
            calc = Math.round(calc);
            return after + calc + ' '+ Main.translation.theme_days + before;

        }

    };

    /*
     * Hide dropdown
     *
     * @since   0.0.8.5 
     */
    Main.hide_dropdown = function( from, to ) {
        'use strict';

        // Hide dropdown
        $('.wrapper .dropdown-options').find('> .dropdown-toggle').attr('aria-expanded', 'false');
        $('.wrapper .dropdown-options').find('> .dropdown-menu').removeClass('show');

    };

    /*
     * Schedule event
     * 
     * @param funcion fun contains the function
     * @param integer interval contains time
     * 
     * @since   0.0.8.5
     */
    Main.schedule_event = function($fun, interval) {

        // Add to queue
        Main.queue = setTimeout($fun, interval);
        
    };

    /*
     * Gets apps for quick menu
     * 
     * @param integer progress contains the progress option
     * 
     * @since   0.0.8.4
     */
    Main.crm_apps_get_apps_menu = function(progress) {   

        // Prepare data to send
        var data = {
            action: 'crm_apps_get_apps_menu',
            key: $('body .theme-apps-menu-box .crm-search-for-apps-menu').val()
        };

		// Set CSRF
        data[$('.main').attr('data-csrf')] = $('.main').attr('data-csrf-value');
        
        // Verify if progress exists
        if ( typeof progress !== 'undefined' ) {

            // Make ajax call
            Main.ajax_call(url + 'user/app-ajax/crm_apps', 'POST', data, 'crm_apps_display_apps_menu_response', 'ajax_onprogress');

            // Set progress bar
            Main.set_progress_bar();

        } else {

            // Make ajax call
            Main.ajax_call(url + 'user/app-ajax/crm_apps', 'POST', data, 'crm_apps_display_apps_menu_response');

        }

    };

    /*
     * Get alerts for users
     * 
     * @since   0.0.8.5
     */    
    Main.theme_notifications_get_alerts =  function () {

        // Prepare data to send
        var data = {
            action: 'theme_get_alerts'
        };
        
        // Make ajax call
        Main.ajax_call(url + 'user/theme-ajax', 'GET', data, 'theme_notifications_display_alerts_response');
        
    };

    /*******************************
    ACTIONS
    ********************************/

    /*
     * Load default content
     * 
     * @since   0.0.8.5 
     */
    $(function () {

        // Schedule event
        Main.schedule_event(function() {

            // Rearrange the sidebar
            Main.rearrange();
            
            // Remove the page loading
            $('.page-loading').remove();
    
        }, 600);

        // Schedule event
        Main.schedule_event(function() {

            // Get users alerts
            Main.theme_notifications_get_alerts();
    
        }, 1500);        

    });

    /*
     * Search for apps
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.4
     */
    $(document).on('keyup', 'body .theme-apps-menu-box .crm-search-for-apps-menu', function (e) {
        e.preventDefault();

        // Verify if input has a value
        if ( $(this).val() !== '' ) {

            // Verify if an event was already scheduled
            if ( typeof Main.queue !== 'undefined' ) {

                // Clear previous timout
                clearTimeout(Main.queue);

            }

            Main.schedule_event(function() {

                // Gets apps for quick menu
                Main.crm_apps_get_apps_menu(1);

            }, 1000);

        } else {

            // Gets apps for quick menu
            Main.crm_apps_get_apps_menu(1);
            
        }

    });

    /*
     * Detect any click
     *
     * @param object e with global object
     */
    $(document).click(function(e) {

        var menu = $( '.sidebar-header > li > ul, .sidebar-bottom > li > ul' );

        if ( typeof e !== 'undefined' ) {

            if ( !menu.is(e.target) && menu.has(e.target).length === 0 ) {

                if ( !$(e.target).closest('li').hasClass('nav-active') ) {

                    // Hide submenu
                    $('.sidebar-header > li, .sidebar-bottom > li').each(function() {

                        if ( $(this).find('ul').length > 0 ) {
                            $(this).removeClass('nav-active');
                            $(this).find('ul').removeAttr('style');
                        }

                    });

                    if ( $(this).find('.theme-apps-menu-box').length > 0 ) {
                        $(this).find('.theme-apps-menu-box').removeAttr('style');
                    }                     

                } 

            }

        }

    });

    /*
     * Detect dropdown show
     *
     * @param object e with global object
     */
    $(document).on('click', '.sidebar > ul > li > a', function (e) {

        // Verify if menu has submenu
        if ( $(this).closest('li').find('ul').length > 0 ) {
            e.preventDefault();

            // Verify if the menu is open
            if ( !$(e.target).closest('li').hasClass('nav-active') ) {

                // Open the submenu
                $(this).closest('li').addClass('nav-active');

                // Remove the focus
                $(this).blur();

                // Add opacity 0
                $('.sidebar .dropdown-menu').css({
                    'opacity': 0
                });

                // Set top
                let top_drop = $(this).offset().top;

                // Set menu to open
                let ul = $(this).closest('li').find('ul');

                // Get submenu height
                let submenu_height = ul.outerHeight();
                
                // Verify if the submenu position
                if ( ($(window).height() - $(this).offset().top) < submenu_height ) {
                    top_drop = top_drop - ((submenu_height + 15) - ($(window).height() - $(this).offset().top));
                } else {
                    top_drop = $(this).offset().top;
                }

                setTimeout(function() {
                    
                    if ( ul.closest('.sidebar-header').length > 0 ) {

                        ul.css({
                            'display': 'block',
                            'transform': 'none',
                            'top': top_drop + 'px',
                            'opacity': 1
                        });

                    } else {

                        ul.css({
                            'display': 'block',
                            'transform': 'none',
                            'top': top_drop + 'px',
                            'opacity': 1
                        });

                    }

                }, 100);

            } else {

                // Hide the submenu
                $(this).closest('li').removeClass('nav-active');
                $(this).closest('li').find('ul').removeAttr('style');

            }

        }

    });

    /*
     * Prevent dropdown close
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.5
     */ 
    $( document ).on( 'click', '.wrapper .dropdown-options > .dropdown-menu', function (e) {
        e.stopPropagation();
    });    

    /*
     * Prevent dropdown close
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.5
     */     
    $( document ).on( 'click', '.wrapper .dropdown-options > .dropdown-menu .dropdown-toggle', function (e) {
        $(this).closest('.dropdown-options').find('> .dropdown-toggle').attr('aria-expanded', 'true');
        $(this).closest('.dropdown-options').find('> .dropdown-menu').addClass('show');
    });        
   
    /*
     * Hide the dropdown options
     * 
     * @param object e with global object
     * 
     * @since   0.0.8.5
     */ 
    $( document ).on( 'click', '.wrapper .btn-dropdown-options-btn', function (e) {
        e.preventDefault();

        // Hide dropdown
        Main.hide_dropdown();
        
    });

    /*
     * Detect apps menu click
     *
     * @param object e with global object
     * 
     * @since   0.0.8.5 
     */  
    $(document).on('click', '.sidebar-header > li > a[href="#crm-apps-menu"]', function (e) {
        e.preventDefault();

        // Remove the focus
        $(this).blur();

        // Gets apps for quick menu
        Main.crm_apps_get_apps_menu(1);

        // Set top
        let top_drop = $(this).offset().top;

        // Set pause
        setTimeout(function() {

            // Display the apps menu box
            $('body .theme-apps-menu-box').css({
                'display': 'block',
                'transform': 'none',
                'top': top_drop + 'px',
                'left': '66px',
                'opacity': 1
            });

        }, 100);

    });

    /*
     * Close a notification's popup
     *
     * @since   0.0.8.5
     */  
    $(document).on('click', '.theme-notifications-popups .theme-notifications-popup-close-btn', function (e) {
        e.preventDefault();

        // Set this
        var $this = $(this);
        
        // Hide
        $this.closest('div').slideToggle('slow');

        // Verify if is an error
        if ( $this.closest('.theme-notifications-error-banner').length < 1 ) {

            // Remove after 1 second
            setTimeout(function() {

                // Remove
                $this.closest('div').remove();

            }, 1000);

        }

        // Prepare data to send
        var data = {
            action: 'theme_hide_alert',
            alert: $this.attr('data-alert')
        };
        
        // Make ajax call
        Main.ajax_call(url + 'user/theme-ajax', 'GET', data, 'theme_notifications_hide_alert_response');        

    });

    /*
     * Close a notification's promo
     *
     * @since   0.0.8.5
     */   
    $(document).on('click', '.theme-notifications-promo-close-btn', function (e) {
        e.preventDefault();
        
        // Hide
        $(this).closest('.theme-notifications-promo').remove();

        // Prepare data to send
        var data = {
            action: 'theme_hide_alert',
            alert: $(this).attr('data-alert')
        };
        
        // Make ajax call
        Main.ajax_call(url + 'user/theme-ajax', 'GET', data, 'theme_notifications_hide_alert_response');        

    });
   
    /*******************************
    RESPONSES
    ********************************/

    /*
     * Track progress ajax request
     *
     * @param integer loaded contains the loaded's data
     * @param integer total contains the total's legth
     * 
     * @since   0.0.8.3
     */
    Main.methods.ajax_onprogress = function(loaded, total) {
        
        // Get percentage
        let percentage = ((loaded/total) * 100).toFixed(2);

        // Set progress bar width
        $('body .theme-send-loading').css('width', percentage + '%');

    };

    /*
     * Display the apps list
     * 
     * @param string status contains the response status
     * @param object data contains the response content
     * 
     * @since   0.0.8.4
     */
    Main.methods.crm_apps_display_apps_menu_response = function ( status, data ) {

        // Remove progress bar
        Main.remove_progress_bar();

        // Verify if the success response exists
        if ( status === 'success' ) {
            
            // Apps container
            var apps = '';

            // List all apps
            for ( var a = 0; a < data.apps.length; a++ ) {     
                
                // Add automation to the container
                apps += '<a href="' + data.apps[a].app_slug + '" class="list-group-item list-group-item-action">'
                    + '<img src="' + data.apps[a].app_cover + '" alt="' + data.apps[a].app_name + '">'
                    + '<span>'
                        + data.apps[a].app_name
                    + '</span>'
                + '</a>';    

            }

            // Display the apps
            $('body .theme-apps-menu-box .list-group').html(apps);
            
        } else {

            // Set the no apps message
            let no_apps_message = '<p class="crm-no-apps-found">'
                + data.message
            + '</p>';

            // Display the no apps message
            $('body .theme-apps-menu-box .list-group').html(no_apps_message);  

        }
        
    };

    /*
     * Display users alerts
     * 
     * @param string status contains the response status
     * @param object data contains the response content
     * 
     * @since   0.0.8.5
     */
    Main.methods.theme_notifications_display_alerts_response = function ( status, data ) {

        // Verify if the success response exists
        if ( status === 'success' ) {

            // List alerts
            for ( var a = 0; a < data.alerts.length; a++ ) {

                // Verify which alert is by type
                if ( parseInt(data.alerts[a].alert_type) === 2 ) {

                    // Set alert's content
                    var content = '<a href="#" class="theme-notifications-popup-close-btn" data-alert="' + data.alerts[a].alert_id + '">'
                        + Main.translation.icon_bi_x
                    + '</a>'
                    + '<div>'
                        + data.alerts[a].content
                    + '</div>';

                    // Set fixed
                    $('.theme-notifications-popups .theme-notifications-fixed-banner').html(content);

                    // Show alert
                    $('.theme-notifications-popups .theme-notifications-fixed-banner').slideToggle('slow');

                } else if ( parseInt(data.alerts[a].alert_type) === 1 ) {

                    // Set alert
                    var alert = data.alerts[a];

                    // Run after 5 seconds
                    setTimeout(function() {

                        // Set alert's content
                        var content = '<a href="#" class="theme-notifications-promo-close-btn" data-alert="' + alert.alert_id + '">'
                            + Main.translation.icon_bi_x
                        + '</a>'
                        + '<div>'
                            + alert.content
                        + '</div>';                          

                        // Set promo
                        $('.theme-notifications-promo .theme-notifications-promo-banner').html(content);                        

                        // Show alert
                        $('.theme-notifications-promo').css({'display': 'flex'});

                        // Zoom promo
                        $('.theme-notifications-promo .theme-notifications-promo-banner').animate({transform: 1},
                            {duration: 100,easing: 'linear',
                            step: function(now) {

                                // Set scale
                                $(this).css('transform','scale('+now+')')
                            }

                        }).css({'opacity': '1'});

                    }, 5000);

                } else if ( parseInt(data.alerts[a].alert_type) === 0 ) {

                    // Set alert's content
                    var content = '<a href="#" class="theme-notifications-popup-close-btn" data-alert="' + data.alerts[a].alert_id + '">'
                        + Main.translation.icon_bi_x
                    + '</a>'
                    + '<div>'
                        + data.alerts[a].content
                    + '</div>';

                    // Set news
                    $('.theme-notifications-popups .theme-notifications-news-banner').html(content);  
                    
                    // Show alert
                    $('.theme-notifications-popups .theme-notifications-news-banner').slideToggle('slow');

                }

            }
            
        }

        // Reload this code every 15 seconds
        setInterval(function () {

            // Prepare data to send
            var data = {
                action: 'theme_get_error_alerts'
            };
            
            // Make ajax call
            Main.ajax_call(url + 'user/theme-ajax', 'GET', data, 'theme_notifications_display_error_alerts_response');

        }, 15000);

    }

    /*
     * Display errors alerts
     * 
     * @param string status contains the response status
     * @param object data contains the response content
     * 
     * @since   0.0.8.4
     */
    Main.methods.theme_notifications_display_error_alerts_response = function ( status, data ) {

        // Verify if the success response exists
        if ( status === 'success' ) {

            // Verify if the alert already exist
            if ( $('.theme-notifications-popups .theme-notifications-error-banner .theme-notifications-popup-close-btn[data-alert="' + data.alerts[0].alert_id + '"]').length < 1 ) {

                // Set alert's content
                var content = '<a href="#" class="theme-notifications-popup-close-btn" data-alert="' + data.alerts[0].alert_id + '">'
                    + Main.translation.icon_bi_x
                + '</a>'
                + '<div>'
                    + data.alerts[0].content
                + '</div>';

                // Set news
                $('.theme-notifications-popups .theme-notifications-error-banner').html(content);  
                
                // Show alert
                $('.theme-notifications-popups .theme-notifications-error-banner').fadeIn('slow');

            }
            
        }

    }

    /*
     * Hide alert response
     * 
     * @param string status contains the response status
     * @param object data contains the response content
     * 
     * @since   0.0.8.5
     */
    Main.methods.theme_notifications_hide_alert_response = function ( status, data ) {}

});