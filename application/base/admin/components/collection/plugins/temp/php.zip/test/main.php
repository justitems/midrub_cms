<?php
/**
 * Midrub Plugins Test
 *
 * This file loads the Test plugin
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://elements.envato.com/license-terms
 * @link     https://www.midrub.com/
 * 
 * @since 0.0.8.4
 */

// Define the page namespace
namespace MidrubBase\Plugins\Collection\Test;

// Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');
defined('MIDRUB_BASE_PLUGINS_TEST') OR define('MIDRUB_BASE_PLUGINS_TEST', MIDRUB_BASE_PATH . 'plugins/collection/test/');
defined('MIDRUB_BASE_PLUGINS_TEST_VERSION') OR define('MIDRUB_BASE_PLUGINS_TEST_VERSION', '0.1');

// Define the namespaces to use
use MidrubBase\Interfaces as MidrubBaseInterfaces;
use MidrubBase\Plugins\Collection\Test\Controllers as MidrubBasePluginsCollectionTestControllers;

/*
 * Main class loads the Test plugin loader
 * 
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://elements.envato.com/license-terms
 * @link     https://www.midrub.com/
 * 
 * @since 0.0.8.4
 */
class Main implements MidrubBaseInterfaces\Plugins {
    
    /**
     * Class variables
     *
     * @since 0.0.8.4
     */
    protected
            $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.4
     */
    public function __construct() {
        
        // Assign the CodeIgniter super-object
        $this->CI =& get_instance();
        
    }
    
    /**
     * The public method ajax processes the ajax's requests
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function ajax() {

        // Verify if the plugin is enabled
        if ( !get_option('plugin_test_enable') ) {
            exit();
        }
        
        // Get action's get input
        $action = $this->CI->input->get('action', TRUE);

        if ( !$action ) {
            $action = $this->CI->input->post('action');
        }
        
        try {
            
            // Call method if exists
            (new MidrubBasePluginsCollectionTestControllers\Ajax)->$action();
            
        } catch (Exception $ex) {
            
            $data = array(
                'success' => FALSE,
                'message' => $ex->getMessage()
            );
            
            echo json_encode($data);
            
        }
        
    }

    /**
     * The public method rest processes the rest's requests
     * 
     * @param string $endpoint contains the requested endpoint
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function rest($endpoint) {

    }
    
    /**
     * The public method cron_jobs loads the cron jobs commands
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function cron_jobs() {
        
    }
    
    /**
     * The public method delete_account is called when user's account is deleted
     * 
     * @param integer $user_id contains the user's ID
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function delete_account($user_id) {}

    /**
     * The public method hooks contains the plugin's hooks
     * 
     * @param string $category contains the hooks category
     * 
     * @since 0.0.8.4
     * 
     * @return void
     */
    public function load_hooks( $category ) {
    }
    
    /**
     * The public method plugin_info contains the plugin's info
     * 
     * @since 0.0.8.4
     * 
     * @return array with plugin's information
     */
    public function plugin_info() {
        
        // Return plugin information
        return array(
            'plugin_name' => "Test Plugin",
            'plugin_description' => "This is a short information about this plugin.",
            'plugin_cover' => base_url('assets/base/plugins/collection/test/screenshot.png'),
            'plugin_slug' => 'test',
            'version' => MIDRUB_BASE_PLUGINS_TEST_VERSION,
            'update_url' => 'https://update.midrub.com/test/',
            'update_code' => TRUE,
            'update_code_url' => 'https://access-codes.midrub.com/',
            'min_version' => '0.0.8.4',
            'max_version' => '0.0.8.4'
        );
        
    }

}

/* End of file main.php */