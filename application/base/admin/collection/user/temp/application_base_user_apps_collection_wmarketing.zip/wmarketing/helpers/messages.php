<?php
/**
 * Messages Helpers
 * 
 * PHP Version 7.3
 *
 * This file contains the class Messages
 * with methods to process the messages data
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Wmarketing\Helpers;

// Constats
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Messages class provides the methods to process the messages data
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
*/
class Messages {
    
    /**
     * Class variables
     *
     * @since 0.0.8.1
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.1
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();
        
        // Load the Wmarketing Automatizations Model
        $this->CI->load->ext_model(MIDRUB_BASE_USER_APPS_WMARKETING . 'models/', 'Wmarketing_automatizations_model', 'wmarketing_automatizations_model');
        
    }

    //-----------------------------------------------------
    // Main class's methods
    //-----------------------------------------------------

    /**
     * The public method messages_for_graph loads messages for graph
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */ 
    public function messages_for_graph() {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('page_id', 'Page ID', 'trim');

            // Get data
            $page_id = $this->CI->input->post('page_id', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Loads messages by popularity
                $messages = $this->CI->wmarketing_automatizations_model->messages_for_graph($this->CI->user_id, $page_id);

                // Verify if messages exists
                if ( $messages ) {

                    // Prepare the success response
                    $data = array(
                        'success' => TRUE,
                        'messages' => $messages,
                        'words' => array(
                            'number_bot_messages' => $this->CI->lang->line('wmarketing_number_bot_messages')
                        )
                    );

                    // Display the success response
                    echo json_encode($data);
                    exit();

                }

            }

        }

        // Prepare the false response
        $data = array(
            'success' => FALSE,
            'words' => array(
                'number_bot_messages' => $this->CI->lang->line('wmarketing_number_bot_messages')
            )
        );

        // Display the false response
        echo json_encode($data);
        
    }

    /**
     * The public method messages_by_popularity loads messages by popularity
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */ 
    public function messages_by_popularity() {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('page_id', 'Page ID', 'trim');
            $this->CI->form_validation->set_rules('page', 'Page', 'trim');

            // Get data
            $page_id = $this->CI->input->post('page_id', TRUE);
            $page = $this->CI->input->post('page', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // If $page is false, set 1
                if (!$page) {
                    $page = 1;
                }

                // Decrease the page
                $page--;

                // Loads messages by popularity
                $messages = $this->CI->wmarketing_automatizations_model->messages_by_popularity($this->CI->user_id, $page_id, $page);

                // Verify if messages exists
                if ( $messages ) {

                    // Calculate total number of messages
                    $total_messages = $this->CI->wmarketing_automatizations_model->messages_by_popularity($this->CI->user_id, $page_id);

                    // Prepare the success response
                    $data = array(
                        'success' => TRUE,
                        'messages' => $messages,
                        'total' => count($total_messages),
                        'page' => ($page + 1)
                    );

                    // Display the success response
                    echo json_encode($data);
                    exit();

                }

            }

        }

        // Prepare the false response
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('wmarketing_no_messages_found')
        );

        // Display the false response
        echo json_encode($data);
        
    }
    
}

/* End of file messages.php */