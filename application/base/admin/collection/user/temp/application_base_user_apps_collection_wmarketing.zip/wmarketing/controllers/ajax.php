<?php

/**
 * Ajax Controller
 *
 * This file processes the app's ajax calls
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Wmarketing\Controllers;

// Constants
defined('BASEPATH') or exit('No direct script access allowed');

// Define the namespaces to use
use MidrubBase\User\Apps\Collection\Wmarketing\Helpers as MidrubBaseUserAppsCollectionWmarketingHelpers;

/*
 * Ajax class processes the app's ajax calls
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */

class Ajax
{

    /**
     * Class variables
     *
     * @since 0.0.8.1
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.1
     */
    public function __construct() {

        // Get codeigniter object instance
        $this->CI = &get_instance();

        // Load language
        $this->CI->lang->load( 'wmarketing_user', $this->CI->config->item('language'), FALSE, TRUE, MIDRUB_BASE_USER_APPS_WMARKETING );

    }

    /**
     * The public method create_category creates a category
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function create_category() {

        // Creates a category
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Categories)->create_category();

    }

    /**
     * The public method get_categories_by_page gets categories by page
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function get_categories_by_page() {

        // Gets categories
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Categories)->get_categories_by_page();

    }

    /**
     * The public method get_all_categories gets all categories
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function get_all_categories() {

        // Gets all categories
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Categories)->get_all_categories();

    }    

    /**
     * The public method delete_category deletes a category
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function delete_category() {

        // Deletes a category
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Categories)->delete_category();

    }

    /**
     * The public method save_automatization saves an automatization
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function save_automatization() {

        // Saves a automatization
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Automatizations)->save_automatization();

    }

    /**
     * The public method update_automatization updates an automatization
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function update_automatization() {

        // Updates a automatization
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Automatizations)->update_automatization();

    }

    /**
     * The public method load_automatizations loads automatizations
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_automatizations() {

        // Load automatizations
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Automatizations)->load_automatizations();

    }

    /**
     * The public method delete_automatizations deletes automatizations
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function delete_automatizations() {

        // Delete automatizations
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Automatizations)->delete_automatizations();

    }

    /**
     * The public method automatization_activity_graph provides information to generate a graph 
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function automatization_activity_graph() {

        // Get automatization to generate a graph
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Automatizations)->automatization_activity_graph();

    }

    /**
     * The public method load_automatization_subscribers gets subscribers for an automatization
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_automatization_subscribers() {

        // Load subscribers for an automatization
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Subscribers)->load_automatization_subscribers();

    }

    /**
     * The public method load_message_subscribers loads message's subscribers
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_message_subscribers() {

        // Load subscribers
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Subscribers)->load_message_subscribers();

    }

    /**
     * The public method load_subscribers gets subscribers
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_subscribers() {

        // Load subscribers
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Subscribers)->load_subscribers();

    }

    /**
     * The public method load_reply_subscribers gets subscribers for a reply
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_reply_subscribers() {

        // Load subscribers for a reply
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Subscribers)->load_reply_subscribers();

    }    

    /**
     * The public method get_all_subscriber_categories gets subscriber's categories
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function get_all_subscriber_categories() {

        // Load categories
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Subscribers)->get_all_subscriber_categories();

    }

    /**
     * The public method select_subscriber_category selects subscriber's categories
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function select_subscriber_category() {

        // Select or unselect a category
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Subscribers)->select_subscriber_category();

    }

    /**
     * The public method get_all_subscriber_messages gets the subscriber's messages
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function get_all_subscriber_messages() {

        // Gets messages
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Subscribers)->get_all_subscriber_messages();

    }

    /**
     * The public method save_subscriber_categories adds or removes categories for to subscriber
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function save_subscriber_categories() {

        // Removes or adds categories
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Subscribers)->save_subscriber_categories();

    }

    /**
     * The public method messages_for_graph returns messages for graph
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function messages_for_graph() {

        // Load messages for graph
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Messages)->messages_for_graph();

    }

    /**
     * The public method messages_by_popularity loads messages by popularity
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function messages_by_popularity() {

        // Load messages by popularity
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Messages)->messages_by_popularity();

    }

    /**
     * The public method load_whatsapp_numbers search for connected numbers and return by page
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_whatsapp_numbers() {

        // Search for numbers
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Numbers)->load_whatsapp_numbers();

    }

    /**
     * The public method save_promotional_message saves promotional message
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function save_promotional_message() {

        // Saves promotional message
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Promotional)->save_promotional_message();

    }    

    /**
     * The public method load_promotional_messages loads promotional messages
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_promotional_messages() {

        // Get promotional messages
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Promotional)->load_promotional_messages();

    }

    /**
     * The public method get_subscribers_by_categories get number of subscribers based on categories
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function get_subscribers_by_categories() {

        // Get number of subscribers
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Promotional)->get_subscribers_by_categories();

    }

    /**
     * The public method delete_promotional_messages deletes promotional messages
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function delete_promotional_messages() {

        // Delete promotional messages
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Promotional)->delete_promotional_messages();

    }

}

/* End of file ajax.php */