<?php
/**
 * Numbers Helpers
 * 
 * PHP Version 7.3
 *
 * This file contains the class Numbers
 * with methods to process the numbers data
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Wmarketing\Helpers;

// Constats
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Numbers class provides the methods to process the numbers data
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
*/
class Numbers {
    
    /**
     * Class variables
     *
     * @since 0.0.8.1
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.1
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();
        
    }

    //-----------------------------------------------------
    // Main class's methods
    //-----------------------------------------------------

    /**
     * The public method load_whatsapp_numbers loads numbers by page
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */ 
    public function load_whatsapp_numbers() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('key', 'Key', 'trim');
            $this->CI->form_validation->set_rules('page', 'Page', 'trim');

            // Get data
            $key = $this->CI->input->post('key', TRUE);
            $page = $this->CI->input->post('page', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare the false response
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('wmarketing_no_numbers_found')
                );

                // Display the false response
                echo json_encode($data);
                exit();
                
            } else {

                // If $page is false, set 1
                if (!$page) {
                    $page = 1;
                }

                // Set the limit
                $limit = 10;
                $page--;

                // Use the base model for a simply sql query
                $get_numbers = $this->CI->base_model->get_data_where(
                    'networks',
                    'network_id, net_id, user_name, secret',
                    array(
                        'network_name' => 'twilio',
                        'user_id' => $this->CI->user_id
                    ),
                    array(),
                    array('user_name' => $this->CI->db->escape_like_str($key)),
                    array(),
                    array(
                        'order' => array('network_id', 'desc'),
                        'start' => ($page * $limit),
                        'limit' => $limit
                    )
                );

                // Verify if numbers exists
                if ( $get_numbers ) {

                    // Use the base model for a simply sql query
                    $total = $this->CI->base_model->get_data_where(
                        'networks',
                        'COUNT(network_id) AS total',
                        array(
                            'network_name' => 'twilio',
                            'user_id' => $this->CI->user_id
                        ),
                        array(),
                        array('user_name' => $this->CI->db->escape_like_str($key)),
                        array(),
                        array(
                            'order' => array('network_id', 'desc'),
                            'start' => ($page * $limit),
                            'limit' => $limit
                        )
                    );

                    // Numbers variable
                    $numbers = array();

                    // List all numbers
                    foreach ( $get_numbers as $pag ) {

                        $numbers[] = array(
                            'network_id' => $pag['network_id'],
                            'user_name' => $pag['user_name']
                        );

                    } 

                    // Prepare the success response
                    $data = array(
                        'success' => TRUE,
                        'numbers' => $numbers
                    );                    

                    // Display the response
                    echo json_encode($data);

                } else {

                    // Prepare the false response
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('wmarketing_no_numbers_found')
                    );

                    // Display the false response
                    echo json_encode($data);

                }
                
            }
            
        }
        
    }

}

/* End of file numbers.php */