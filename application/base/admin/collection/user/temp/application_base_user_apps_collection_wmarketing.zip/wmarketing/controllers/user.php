<?php
/**
 * User Controller
 *
 * This file loads the Marketing app in the user panel
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Wmarketing\Controllers;

// Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * User class loads the Wmarketing app loader
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */
class User {
    
    /**
     * Class variables
     *
     * @since 0.0.8.1
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.1
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();
        
        // Load Wmarketing User language
        $this->CI->lang->load( 'wmarketing_user', $this->CI->config->item('language'), FALSE, TRUE, MIDRUB_BASE_USER_APPS_WMARKETING );
        
    }
    
    /**
     * The public method view loads the app's template
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function view() {

        // Set the page's title
        set_the_title($this->CI->lang->line('wmarketing'));

        // Set Wmarketing's styles
        set_css_urls(array('stylesheet', base_url('assets/base/user/apps/collection/wmarketing/styles/css/styles.css?ver=' . MIDRUB_BASE_USER_APPS_WMARKETING_VERSION), 'text/css', 'all'));

        // Verify if is not the main app's page
        if ( $this->CI->input->get('p', TRUE) ) {

            switch ( $this->CI->input->get('p', TRUE) ) {

                case 'promotional-messages':

                    // Verify if the user has permission to use promotional messages
                    if ( !plan_feature('app_wmarketing_promotional_message') ) {

                        // Display 404 page
                        show_404();

                    }

                    // Verify if automatization's ID exists
                    if ( is_numeric($this->CI->input->get('message', TRUE)) ) {

                        // Set Marketing's Message Js
                        set_js_urls(array(base_url('assets/base/user/apps/collection/wmarketing/js/message.js?ver=' . MIDRUB_BASE_USER_APPS_WMARKETING_VERSION)));

                        // Get message with base model
                        $message = $this->CI->base_model->get_data_where('whatsapp_promotional', 'whatsapp_promotional.name, whatsapp_promotional.scheduled, whatsapp_promotional.created, whatsapp_promotional_message.*', array(
                            'whatsapp_promotional.message_id' => $this->CI->input->get('message', TRUE),
                            'whatsapp_promotional.user_id' => $this->CI->user_id
                        ),
                        array(),
                        array(),
                        array(array(
                            'table' => 'whatsapp_promotional_message',
                            'condition' => 'whatsapp_promotional.message_id=whatsapp_promotional_message.message_id',
                            'join_from' => 'LEFT'
                        )));

                        // Verify if message exists
                        if ( $message ) {

                            // Icon time
                            $time_icon = '<i class="lni-alarm-clock"></i> ';

                            // Verify if message should be published
                            if ( $message[0]['scheduled'] > time() ) {

                                // Set new time icon
                                $time_icon = '<i class="lni-timer"></i> ';

                            }

                            // View's params
                            $view_params = array(
                                'message_id' => $this->CI->input->get('message', TRUE),
                                'name' => $message[0]['name'],
                                'time_text' => $time_icon . strip_tags(calculate_time($message[0]['scheduled'], time())),
                                'type' => $message[0]['type'],
                                'body' => $message[0]['body']
                            );

                            // Use the base model for a simply sql query
                            $get_categories = $this->CI->base_model->get_data_where(
                                'whatsapp_promotional_categories',
                                'chatbot_categories.category_id, chatbot_categories.name',
                                array(
                                    'whatsapp_promotional_categories.message_id' => $this->CI->input->get('message', TRUE),
                                ),
                                array(),
                                array(),
                                array(array(
                                    'table' => 'chatbot_categories',
                                    'condition' => 'whatsapp_promotional_categories.category_id=chatbot_categories.category_id',
                                    'join_from' => 'LEFT'
                                ))
                            );

                            // Use the base model for a simply sql query
                            $get_sent = $this->CI->base_model->get_data_where(
                                'whatsapp_promotional_history',
                                'COUNT(message_id) AS total, SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as success',
                                array(
                                    'message_id' => $this->CI->input->get('message', TRUE),
                                )
                            );

                            // Verify if the message was sent
                            if ( $get_sent ) {

                                // Set total subscribers
                                $view_params['sent_subscribers'] = $get_sent[0]['total'];

                                // Set success sent
                                $view_params['sent_success'] = $get_sent[0]['success']?$get_sent[0]['success']:0;
                                
                            } else {

                                // Set total subscribers
                                $view_params['sent_subscribers'] = 0;

                                // Set success sent
                                $view_params['sent_success'] = 0;

                            }

                            // Verify if categories exists
                            if ( $get_categories ) {
                                $view_params['categories'] = $get_categories;
                            }

                            // Set views params
                            set_user_view(

                                $this->CI->load->ext_view(
                                    MIDRUB_BASE_USER_APPS_WMARKETING . 'views',
                                    'message',
                                    $view_params,
                                    true
                                )

                            );

                        } else {

                            // Display 404 page
                            show_404();

                        }

                    } else {

                        // Set Marketing's Promotional Messages Js
                        set_js_urls(array(base_url('assets/base/user/apps/collection/wmarketing/js/promotional-messages.js?ver=' . MIDRUB_BASE_USER_APPS_WMARKETING_VERSION)));

                        // Set views params
                        set_user_view(

                            $this->CI->load->ext_view(
                                MIDRUB_BASE_USER_APPS_WMARKETING . 'views',
                                'promotional_messages',
                                array(),
                                true
                            )

                        );

                    }

                    break;

                case 'subscribers':

                    // Verify if subscriber's ID exists
                    if ( is_numeric( $this->CI->input->get('subscriber', TRUE) ) ) {

                        // Set Marketing's Subscriber Js
                        set_js_urls(array(base_url('assets/base/user/apps/collection/wmarketing/js/subscriber.js?ver=' . MIDRUB_BASE_USER_APPS_WMARKETING_VERSION)));

                        // Params to pass to view
                        $params = array();

                        // Use the base model to get the subscriber's data
                        $get_subscriber = $this->CI->base_model->get_data_where(
                            'chatbot_subscribers',
                            'chatbot_subscribers.subscriber_id, chatbot_subscribers.net_id, chatbot_subscribers.name, networks.secret',
                            array(
                                'chatbot_subscribers.subscriber_id' => $this->CI->input->get('subscriber', TRUE),
                                'chatbot_subscribers.user_id' => $this->CI->user_id
                            ),
                            array(),
                            array(),
                            array(array(
                                'table' => 'networks',
                                'condition' => 'chatbot_subscribers.page_id=networks.network_id',
                                'join_from' => 'LEFT'
                            ))
                        );

                        // Verify if subscriber exists
                        if ( $get_subscriber ) {

                            // Set subscriber's id
                            $params['subscriber_id'] = $get_subscriber[0]['subscriber_id'];                            

                            // Set subscriber's name
                            $params['name'] = $get_subscriber[0]['name'];

                            // Set default user's image
                            $params['image'] = base_url('assets/img/avatar-placeholder.png');

                        } else {

                            // Display 404 page
                            show_404();
                            
                        }

                        // Set views params
                        set_user_view(

                            $this->CI->load->ext_view(
                                MIDRUB_BASE_USER_APPS_WMARKETING . 'views',
                                'subscriber',
                                $params,
                                true
                            )

                        );

                    } else {

                        // Set Marketing's Subscribers Js
                        set_js_urls(array(base_url('assets/base/user/apps/collection/wmarketing/js/subscribers-list.js?ver=' . MIDRUB_BASE_USER_APPS_WMARKETING_VERSION)));

                        // Set views params
                        set_user_view(

                            $this->CI->load->ext_view(
                                MIDRUB_BASE_USER_APPS_WMARKETING . 'views',
                                'subscribers',
                                array(),
                                true
                            )

                        );

                    }

                    break;

                case 'audit-logs':

                    // Set Chart JS
                    set_js_urls(array('//www.chartjs.org/dist/2.7.2/Chart.js'));

                    // Set Utils JS
                    set_js_urls(array('//www.chartjs.org/samples/latest/utils.js'));

                    // Set Marketing's Audit Js
                    set_js_urls(array(base_url('assets/base/user/apps/collection/wmarketing/js/audit-logs.js?ver=' . MIDRUB_BASE_USER_APPS_WMARKETING_VERSION)));

                    // Params to pass to view
                    $params = array(); 
                    
                    // Use the base model to get the Whatsapp Numbers count
                    $whatsapp_numbers = $this->CI->base_model->get_data_where(
                        'networks',
                        'COUNT(network_id) AS total',
                        array(
                            'network_name' => 'twilio',
                            'user_id' => $this->CI->user_id
                        )
                    );

                    // Verify if Whatsapp Numbers exists
                    if ( $whatsapp_numbers ) {

                        // Set number of Whatsapp's numbers
                        $params['total_numbers'] = $whatsapp_numbers[0]['total'];

                    } else {

                        // Set number of Whatsapp's numbers
                        $params['total_numbers'] = 0;                        

                    }

                    // Get total number of subscribers with base model
                    $subscribers = $this->CI->base_model->get_data_where(
                        'chatbot_subscribers',
                        'COUNT(subscriber_id) AS total',
                        array(
                            'user_id' => $this->CI->user_id
                        )
                    );

                    // Verify if subscribers exists
                    if ( $subscribers ) {

                        // Set number of subscribers
                        $params['total_subscribers'] = $subscribers[0]['total'];

                    } else {

                        // Set number of subscribers
                        $params['total_subscribers'] = 0;                        

                    }

                    // Get total number of messages with base model
                    $messages = $this->CI->base_model->get_data_where(
                        'whatsapp_automatizations_history',
                        'COUNT(history_id) AS total',
                        array(
                            'user_id' => $this->CI->user_id
                        )
                    );

                    // Verify if messages exists
                    if ( $messages ) {

                        // Set number of messages
                        $params['total_messages'] = $messages[0]['total'];

                    } else {

                        // Set number of messages
                        $params['total_messages'] = 0;                        

                    }                    

                    // Set views params
                    set_user_view(

                        $this->CI->load->ext_view(
                            MIDRUB_BASE_USER_APPS_WMARKETING . 'views',
                            'audit_logs',
                            $params,
                            true
                        )

                    );

                    break;

                default:

                    // Display 404 page
                    show_404();

                    break;

            }

        } else {

            // Verify if automatization's ID exists
            if ( is_numeric($this->CI->input->get('automatization', TRUE)) ) {

                // Set Marketing's Automatization Js
                set_js_urls(array(base_url('assets/base/user/apps/collection/wmarketing/js/automatization.js?ver=' . MIDRUB_BASE_USER_APPS_WMARKETING_VERSION)));

                // Set Chart JS
                set_js_urls(array('//www.chartjs.org/dist/2.7.2/Chart.js')); 

                // Set Utils JS
                set_js_urls(array('//www.chartjs.org/samples/latest/utils.js'));   

                // Get automatization with base model
                $automatization = $this->CI->base_model->get_data_where('whatsapp_automatizations', 'whatsapp_automatizations.name, whatsapp_automatizations.time, whatsapp_automatizations_response.*', array(
                    'whatsapp_automatizations.automatization_id' => $this->CI->input->get('automatization', TRUE),
                    'whatsapp_automatizations.user_id' => $this->CI->user_id
                ),
                array(),
                array(),
                array(array(
                    'table' => 'whatsapp_automatizations_response',
                    'condition' => 'whatsapp_automatizations.automatization_id=whatsapp_automatizations_response.automatization_id',
                    'join_from' => 'LEFT'
                )));

                // Verify if automatization exists
                if ( $automatization ) {

                    // View's params
                    $view_params = array(
                        'automatization_id' => $this->CI->input->get('automatization', TRUE),
                        'name' => $automatization[0]['name'],
                        'time_text' => $this->get_time_text($automatization[0]['time']),
                        'time' => $automatization[0]['time'],
                        'type' => $automatization[0]['type'],
                        'body' => $automatization[0]['body']
                    );

                    // Use the base model for a simply sql query
                    $get_categories = $this->CI->base_model->get_data_where(
                        'whatsapp_automatizations_categories',
                        'chatbot_categories.category_id, chatbot_categories.name',
                        array(
                            'whatsapp_automatizations_categories.automatization_id' => $this->CI->input->get('automatization', TRUE),
                        ),
                        array(),
                        array(),
                        array(array(
                            'table' => 'chatbot_categories',
                            'condition' => 'whatsapp_automatizations_categories.category_id=chatbot_categories.category_id',
                            'join_from' => 'LEFT'
                        ))
                    );

                    // Verify if categories exists
                    if ( $get_categories ) {
                        $view_params['categories'] = $get_categories;
                    }

                    // Set views params
                    set_user_view(

                        $this->CI->load->ext_view(
                            MIDRUB_BASE_USER_APPS_WMARKETING . 'views',
                            'automatization',
                            $view_params,
                            true
                        )

                    );

                } else {

                    // Display 404 page
                    show_404();

                }

            } else {

                // Set Marketing's Automatizations Js
                set_js_urls(array(base_url('assets/base/user/apps/collection/wmarketing/js/automatizations.js?ver=' . MIDRUB_BASE_USER_APPS_WMARKETING_VERSION)));

                // Set views params
                set_user_view(

                    $this->CI->load->ext_view(
                        MIDRUB_BASE_USER_APPS_WMARKETING . 'views',
                        'automatizations',
                        array(),
                        true
                    )

                );

            }

        }
        
    }

    /**
     * The protected method get_time_text provides the time's text
     * 
     * @param integer $time_id contains the time's ID
     * 
     * @since 0.0.8.1
     * 
     * @return string with time's text
     */
    public function get_time_text($time_id) {

        switch ( $time_id ) {

            case '1':

                return '1 ' . $this->CI->lang->line('wmarketing_hour');

            case '2':

                return '2 ' . $this->CI->lang->line('wmarketing_hours');

            case '3':

                return '3 ' . $this->CI->lang->line('wmarketing_hours');
                
            case '4':

                return '5 ' . $this->CI->lang->line('wmarketing_hours');
                
            case '5':

                return '7 ' . $this->CI->lang->line('wmarketing_hours');  
                
            case '6':

                return '10 ' . $this->CI->lang->line('wmarketing_hours'); 
                
            case '7':

                return '12 ' . $this->CI->lang->line('wmarketing_hours');    
                
            case '8':

                return '15 ' . $this->CI->lang->line('wmarketing_hours');  
                
            case '9':

                return '20 ' . $this->CI->lang->line('wmarketing_hours');  
                
            case '10':

                return '24 ' . $this->CI->lang->line('wmarketing_hours');                 

            default:

                return $this->CI->lang->line('wmarketing_immediately');

        }
        
    }

}

/* End of file user.php */