<?php
/**
 * Midrub Apps Wmarketing
 *
 * This file loads the Wmarketing app
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Wmarketing;

// Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');
defined('MIDRUB_BASE_USER_APPS_WMARKETING') OR define('MIDRUB_BASE_USER_APPS_WMARKETING', MIDRUB_BASE_USER . 'apps/collection/wmarketing/');
defined('MIDRUB_BASE_USER_APPS_WMARKETING_VERSION') OR define('MIDRUB_BASE_USER_APPS_WMARKETING_VERSION', '0.0.3');

// Define the namespaces to use
use MidrubBase\User\Interfaces as MidrubBaseUserInterfaces;
use MidrubBase\User\Apps\Collection\Wmarketing\Controllers as MidrubBaseUserAppsCollectionWmarketingControllers;

/*
 * Main class loads the Wmarketing app loader
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */
class Main implements MidrubBaseUserInterfaces\Apps {
    
    /**
     * Class variables
     *
     * @since 0.0.8.1
     */
    protected
            $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.1
     */
    public function __construct() {
        
        // Assign the CodeIgniter super-object
        $this->CI =& get_instance();
        
    }

    /**
     * The public method check_availability checks if the app is available
     *
     * @return boolean true or false
     */
    public function check_availability() {

        // Verify if the app is enabled
        if ( !get_option('app_wmarketing_enable') || !plan_feature('app_wmarketing') || !team_role_permission('marketing') ) {
            return false;
        } else {
            return true;
        }
        
    }
    
    /**
     * The public method user loads the app's main page in the user panel
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function user() {
        
        // Verify if the app is enabled
        if ( !get_option('app_wmarketing_enable') || !plan_feature('app_wmarketing') || !team_role_permission('marketing') ) {
            show_404();
        }
        
        // Instantiate the class
        (new MidrubBaseUserAppsCollectionWmarketingControllers\User)->view();
        
    }    

    /**
     * The public method ajax processes the ajax's requests
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function ajax() {
        
        // Verify if the app is enabled
        if ( !get_option('app_wmarketing_enable') || !plan_feature('app_wmarketing') || !team_role_permission('marketing') ) {
            exit();
        }        
        
        // Get action's get input
        $action = $this->CI->input->get('action');

        // Get action's post input
        if ( !$action ) {
            $action = $this->CI->input->post('action');
        }
        
        try {
            
            // Call method if exists
            (new MidrubBaseUserAppsCollectionWmarketingControllers\Ajax)->$action();
            
        } catch (Exception $ex) {
            
            $data = array(
                'success' => FALSE,
                'message' => $ex->getMessage()
            );
            
            echo json_encode($data);
            
        }
        
    }

    /**
     * The public method rest processes the rest's requests
     * 
     * @param string $endpoint contains the requested endpoint
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function rest($endpoint) {

    }
    
    /**
     * The public method cron_jobs loads the cron jobs commands
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function cron_jobs() {

        // Verify if the app is enabled
        if ( get_option('app_wmarketing_enable') ) {

            // Send automatizations
            (new MidrubBaseUserAppsCollectionWmarketingControllers\Cron)->send_automatizations();

            // Process automatizations
            (new MidrubBaseUserAppsCollectionWmarketingControllers\Cron)->scheduled_automatizations();

            // Send promotional messages
            (new MidrubBaseUserAppsCollectionWmarketingControllers\Cron)->send_promotional_messages();

        }

    }
    
    /**
     * The public method delete_account is called when user's account is deleted
     * 
     * @param integer $user_id contains the user's ID
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function delete_account($user_id) {

        // Require the User Inc
        require_once MIDRUB_BASE_USER_APPS_WMARKETING . 'inc/user.php';

        // Delete all user's records in this app
        delete_user_from_facebook_wmarketing($user_id);

    }

    /**
     * The public method hooks contains the app's hooks
     * 
     * @param string $category contains the hooks category
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_hooks( $category ) {

        // Load and run hooks based on category
        switch ( $category ) {

            case 'admin_init':

                // Load the admin app's language files
                $this->CI->lang->load('wmarketing_admin', $this->CI->config->item('language'), FALSE, TRUE, MIDRUB_BASE_USER_APPS_WMARKETING);

                // Verify which component is
                if ( ( md_the_component_variable('component') === 'user' ) && ( $this->CI->input->get('app', TRUE) === 'wmarketing' ) ) {

                    // Require the Admin Inc
                    md_include_component_file(MIDRUB_BASE_USER_APPS_WMARKETING . 'inc/admin.php');

                } else if ( ( md_the_component_variable('component') === 'user' ) && ( md_the_component_variable('component_display') === 'plans' ) ) {

                    // Require the Plans Inc
                    md_include_component_file(MIDRUB_BASE_USER_APPS_WMARKETING . 'inc/plans.php');

                }

                break;

            case 'user_init':

                // Verify which component is
                if ( md_the_component_variable('component') === 'team' ) {

                    if ( get_option('app_wmarketing_enable') && plan_feature('app_wmarketing') ) {

                        // Load the app's language files
                        $this->CI->lang->load('wmarketing_member', $this->CI->config->item('language'), FALSE, TRUE, MIDRUB_BASE_USER_APPS_WMARKETING);

                        // Require the Permissions Inc
                        md_include_component_file(MIDRUB_BASE_USER_APPS_WMARKETING . 'inc/members.php');

                    }

                }

                break;

        }

        // Require the General Inc
        get_the_file(MIDRUB_BASE_USER_APPS_WMARKETING . 'inc/general.php');

    }

    /**
     * The public method guest contains the app's access for guests
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function guest() {

        show_404();

    }
    
    /**
     * The public method app_info contains the app's info
     * 
     * @since 0.0.8.1
     * 
     * @return array with app's information
     */
    public function app_info() {
        
        // Return app information
        return array(
            'app_name' => $this->CI->lang->line('wmarketing'),
            'app_slug' => 'wmarketing',
            'app_icon' => '<i class="fab fa-whatsapp"></i>',
            'version' => MIDRUB_BASE_USER_APPS_WMARKETING_VERSION,
            'update_url' => 'https://update.midrub.com/wmarketing/',
            'update_code' => TRUE,
            'update_code_url' => 'https://access-codes.midrub.com/',
            'min_version' => '0.0.7.9',
            'max_version' => '0.0.8.2'
        );
        
    }

}

/* End of file main.php */