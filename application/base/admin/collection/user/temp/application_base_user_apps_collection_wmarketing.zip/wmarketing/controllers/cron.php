<?php
/**
 * Cron Controller
 *
 * This file loads the Wmarketing's cron job commands
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Wmarketing\Controllers;

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

// Define the namespaces to use
use MidrubBase\User\Apps\Collection\Wmarketing\Helpers as MidrubBaseUserAppsCollectionWmarketingHelpers;

/*
 * Cron class loads the app's cron job commands
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */
class Cron {
    
    /**
     * Class variables
     *
     * @since 0.0.8.1
     */
    protected $CI, $social_accounts = array();

    /**
     * Initialise the Class
     *
     * @since 0.0.8.1
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();
        
        // Load Wmarketing User language
        $this->CI->lang->load( 'wmarketing_user', $this->CI->config->item('language'), FALSE, TRUE, MIDRUB_BASE_USER_APPS_WMARKETING );
        
    }
    
    /**
     * The public method send_automatizations sends automatizations
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function send_automatizations() {
        
        // Send automatization
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Automatizations)->send_automatizations();
        
    }

    /**
     * The public method scheduled_automatizations processes the scheduled automatizations
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function scheduled_automatizations() {
        
        // Process a scheduled automatization
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Automatizations)->scheduled_automatizations();
        
    }

    /**
     * The public method send_promotional_messages sends promotional messages
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function send_promotional_messages() {
        
        // Send scheduled promotional messages
        (new MidrubBaseUserAppsCollectionWmarketingHelpers\Promotional)->send_promotional_messages();
        
    }

}

/* End of file cron.php */