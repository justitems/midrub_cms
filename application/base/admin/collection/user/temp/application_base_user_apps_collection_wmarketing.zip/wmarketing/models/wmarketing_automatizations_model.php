<?php
/**
 * Wmarketing Automatizations Model
 *
 * PHP Version 7.3
 *
 * Wmarketing_automatizations_model file contains the Wmarketing Automatizations Model
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Wmarketing_automatizations_model class - operates the marketing_automatizations table.
 *
 * @since 0.0.8.1
 * 
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */
class Wmarketing_automatizations_model extends CI_MODEL {
    
    /**
     * Class variables
     */
    private $table = 'whatsapp_automatizations';

    /**
     * Initialise the model
     */
    public function __construct() {
        
        // Call the Model constructor
        parent::__construct();

        // Get the table
        $whatsapp_automatizations = $this->db->table_exists('whatsapp_automatizations');

        // Verify if the table exists
        if ( !$whatsapp_automatizations ) {

            // Create the table
            $this->db->query('CREATE TABLE IF NOT EXISTS `whatsapp_automatizations` (
                              `automatization_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `user_id` int(11) NOT NULL,
                              `name` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                              `time` smallint(2) NOT NULL,
                              `created` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
        }

        // Get the table
        $whatsapp_automatizations_response = $this->db->table_exists('whatsapp_automatizations_response');

        // Verify if the table exists
        if ( !$whatsapp_automatizations_response ) {

            // Create the table
            $this->db->query('CREATE TABLE IF NOT EXISTS `whatsapp_automatizations_response` (
                              `response_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `automatization_id` bigint(20) NOT NULL,
                              `body` VARBINARY(4000) NOT NULL,
                              `type` tinyint(1) NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
        }

        // Get the table
        $whatsapp_automatizations_categories = $this->db->table_exists('whatsapp_automatizations_categories');

        // Verify if the table exists
        if ( !$whatsapp_automatizations_categories ) {

            // Create the table
            $this->db->query('CREATE TABLE IF NOT EXISTS `whatsapp_automatizations_categories` (
                              `id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `automatization_id` bigint(20) NOT NULL,
                              `category_id` bigint(20) NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');

        }
        
        // Set the tables value
        $this->tables = $this->config->item('tables', $this->table);
        
    }

    /**
     * The public method get_automatization_by_category_id gets automatization by category's id
     *
     * @param integer $user_id contains the user's ID
     * @param integer $category_id contains the category's ID
     * 
     * @return array with suggestions
     */
    public function get_automatization_by_category_id( $user_id, $category_id ) {
        
        $this->db->select('whatsapp_automatizations.automatization_id, whatsapp_automatizations.time, whatsapp_automatizations_response.body, whatsapp_automatizations_response.type');
        $this->db->from('whatsapp_automatizations_categories');
        $this->db->join('whatsapp_automatizations', 'whatsapp_automatizations_categories.automatization_id=whatsapp_automatizations.automatization_id', 'LEFT');
        $this->db->join('whatsapp_automatizations_response', 'whatsapp_automatizations_categories.automatization_id=whatsapp_automatizations_response.automatization_id', 'LEFT');
        $this->db->where(array(
            'whatsapp_automatizations.user_id' => $user_id,
            'whatsapp_automatizations_categories.category_id' => $category_id
        ));
        $query = $this->db->get();
        
        // Verify if data exists
        if ( $query->num_rows() > 0 ) {
            
            // Return data
            return $query->result_array();
            
        } else {
            
            return false;
            
        }
        
    }

    /**
     * The public method get_scheduled_automatization gets one scheduled automatization
     * 
     * @return array with automatization
     */
    public function get_scheduled_automatization() {
        
        $this->db->select('whatsapp_automatizations_history.*, networks.net_id, networks.user_name, networks.token, networks.secret, chatbot_subscribers.net_id AS user_net_id, chatbot_subscribers.name');
        $this->db->from('whatsapp_automatizations_history');
        $this->db->join('networks', 'whatsapp_automatizations_history.page_id=networks.network_id', 'LEFT');
        $this->db->join('chatbot_subscribers', 'whatsapp_automatizations_history.subscriber_id=chatbot_subscribers.subscriber_id', 'LEFT');
        $this->db->where(array(
            'whatsapp_automatizations_history.status >' => 1,
            'whatsapp_automatizations_history.scheduled <' => time()
        ));
        $this->db->limit(1);
        $query = $this->db->get();
        
        // Verify if data exists
        if ( $query->num_rows() > 0 ) {
            
            // Return data
            return $query->result_array();
            
        } else {
            
            return false;
            
        }
        
    }

    /**
     * The public method automatization_activity_graph returns the automatization's activity
     * 
     * @param integer $user_id contains the user's ID
     * @param integer $automatization_id contains the automatization's ID
     * 
     * @return array with activity or boolean false
     */
    public function automatization_activity_graph($user_id, $automatization_id) {

        $this->db->select('LEFT(FROM_UNIXTIME(created),10) as datetime', false);
        $this->db->select('COUNT(history_id) as number', false);
        $this->db->from('whatsapp_automatizations_history');
        $this->db->where(
            array(
                'user_id' => $user_id,
                'automatization_id'=> $automatization_id,
                'created >' => strtotime('-31day', time())
            )
        );
        $this->db->group_by('datetime');
        $query = $this->db->get();
        
        // Verify if data exists
        if ( $query->num_rows() > 0 ) {
            
            // Return data
            return $query->result_array();
            
        } else {
            
            return false;
            
        }

    }

    /**
     * The public method messages_for_graph returns messages for graph
     * 
     * @param integer $user_id contains the user's ID
     * @param integer $page_id contains the page's ID
     * 
     * @return array with messages or boolean false
     */
    public function messages_for_graph($user_id, $page_id=NULL) {

        $this->db->select('LEFT(FROM_UNIXTIME(created),10) as datetime', false);
        $this->db->select('COUNT(history_id) as number', false);
        $this->db->from('whatsapp_automatizations_history');

        // Verify if page's ID exists
        if ( $page_id ) {

            $this->db->where(
                array(
                    'user_id' => $user_id,
                    'page_id'=> $page_id,
                    'created >' => strtotime('-31day', time())
                )
            );

        } else {

            $this->db->where(
                array(
                    'user_id' => $user_id,
                    'created >' => strtotime('-31day', time())
                )
            );

        }
        
        $this->db->group_by('datetime');
        $query = $this->db->get();
        
        // Verify if data exists
        if ( $query->num_rows() > 0 ) {
            
            // Return data
            return $query->result_array();
            
        } else {
            
            return false;
            
        }

    }

    /**
     * The public method messages_by_popularity gets messages by popularity
     * 
     * @param integer $page_id contains the page's ID
     * @param integer $page contains the page's number
     * 
     * @return array with messages or boolean false
     */
    public function messages_by_popularity($user_id, $page_id, $page=0) {

        $this->db->select('whatsapp_automatizations.name, whatsapp_automatizations_history.type, COUNT(whatsapp_automatizations_history.history_id) as number', false);
        $this->db->from('whatsapp_automatizations_history');
        $this->db->join('whatsapp_automatizations', 'whatsapp_automatizations_history.automatization_id=whatsapp_automatizations.automatization_id', 'LEFT');

        // Verify if page's ID exists
        if ( $page_id ) {

            $this->db->where(
                array(
                    'whatsapp_automatizations_history.user_id' => $user_id,
                    'whatsapp_automatizations_history.page_id'=> $page_id
                )
            );

        } else {

            $this->db->where(
                array(
                    'whatsapp_automatizations_history.user_id' => $user_id
                )
            );
            
        }

        $this->db->group_by('whatsapp_automatizations_history.automatization_id');
        $this->db->order_by('number', 'DESC');

        // Verify if $page is positive otherwise return all results
        if ( $page ) {

            // Set number of items and page
            $this->db->limit(10, ($page * 10) );

        }
        
        $query = $this->db->get();
        
        // Verify if data exists
        if ( $query->num_rows() > 0 ) {
            
            // Return data
            return $query->result_array();
            
        } else {
            
            return false;
            
        }

    }
    
}

/* End of file wmarketing_automatizations_model.php */