<?php

/**
 * Wmarketing Promotional Model
 *
 * PHP Version 7.3
 *
 * Wmarketing_promotional_model file contains the Wmarketing Promotional Model
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */

// Constants
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Wmarketing_promotional_model class - operates the whatsapp_promotional table.
 *
 * @since 0.0.8.1
 * 
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */
class Wmarketing_promotional_model extends CI_MODEL
{

  /**
   * Class variables
   */
  private $table = 'whatsapp_promotional';

  /**
   * Initialise the model
   */
  public function __construct()
  {

    // Call the Model constructor
    parent::__construct();

    // Get the table
    $promotional = $this->db->table_exists('whatsapp_promotional');

    // Verify if the table exists
    if (!$promotional) {

      // Create the table
      $this->db->query('CREATE TABLE IF NOT EXISTS `whatsapp_promotional` (
                              `message_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `user_id` int(11) NOT NULL,
                              `name` TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                              `status` tinyint(1) NOT NULL,
                              `scheduled` varchar(30) NOT NULL,
                              `created` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
    }

    // Get the table
    $promotional_message = $this->db->table_exists('whatsapp_promotional_message');

    // Verify if the table exists
    if (!$promotional_message) {

      // Create the table
      $this->db->query('CREATE TABLE IF NOT EXISTS `whatsapp_promotional_message` (
                              `id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `message_id` bigint(20) NOT NULL,
                              `body` VARBINARY(4000) NOT NULL,
                              `type` tinyint(1) NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
    }

    // Get the table
    $promotional_categories = $this->db->table_exists('whatsapp_promotional_categories');

    // Verify if the table exists
    if (!$promotional_categories) {

      // Create the table
      $this->db->query('CREATE TABLE IF NOT EXISTS `whatsapp_promotional_categories` (
                              `id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `message_id` bigint(20) NOT NULL,
                              `category_id` bigint(20) NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
    }

    // Get the table
    $whatsapp_promotional_history = $this->db->table_exists('whatsapp_promotional_history');

    // Verify if the table exists
    if (!$whatsapp_promotional_history) {

      // Create the table
      $this->db->query('CREATE TABLE IF NOT EXISTS `whatsapp_promotional_history` (
                              `history_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `user_id` int(11) NOT NULL,
                              `page_id` bigint(20) NOT NULL,
                              `message_id` bigint(20) NOT NULL,
                              `subscriber_id` bigint(20) NOT NULL,
                              `body` VARBINARY(4000) NOT NULL,
                              `error` VARBINARY(4000) NOT NULL,
                              `type` tinyint(1) NOT NULL,
                              `status` tinyint(1) NOT NULL,
                              `source` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                              `created` varchar(30) NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
    }

    // Set the tables value
    $this->tables = $this->config->item('tables', $this->table);
  }

  /**
   * The public method get_scheduled_message gets one scheduled message
   * 
   * @return array with message
   */
  public function get_scheduled_message()
  {

    $this->db->select('whatsapp_promotional.*, whatsapp_promotional_message.body, whatsapp_promotional_message.type');
    $this->db->from('whatsapp_promotional');
    $this->db->join('whatsapp_promotional_message', 'whatsapp_promotional.message_id=whatsapp_promotional_message.message_id', 'LEFT');
    $this->db->where(array(
      'whatsapp_promotional.status' => 2,      
      'whatsapp_promotional.scheduled <' => time()
    ));
    $this->db->limit(1);
    $query = $this->db->get();

    // Verify if data exists
    if ($query->num_rows() > 0) {

      // Return data
      return $query->result_array();

    } else {

      return false;

    }

  }

  /**
   * The public method get_subscribers_by_message gets subscribers by promotional message's ID
   * 
   * @param integer $message_id contains the message's ID
   * 
   * @return array with subscribers or boolean false
   */
  public function get_subscribers_by_message($message_id)
  {

    // Get subscribers
    $this->db->select('chatbot_subscribers.*, networks.network_id, networks.net_id, networks.user_name, networks.token, networks.secret, chatbot_subscribers.net_id AS user_net_id, , chatbot_subscribers.name');
    $this->db->from('chatbot_subscribers');
    $this->db->join('chatbot_subscribers_categories', 'chatbot_subscribers.subscriber_id=chatbot_subscribers_categories.subscriber_id', 'LEFT');
    $this->db->join('whatsapp_promotional_categories', 'chatbot_subscribers_categories.category_id=whatsapp_promotional_categories.category_id', 'LEFT');
    $this->db->join('networks', 'chatbot_subscribers.page_id=networks.network_id', 'LEFT');
    $this->db->where_in('whatsapp_promotional_categories.message_id', $message_id);
    $this->db->group_by('chatbot_subscribers.subscriber_id');
    $query = $this->db->get();

    // Verify if data exists
    if ($query->num_rows() > 0) {

      // Return data
      return $query->result_array();

    } else {

      return false;

    }

  }

}

/* End of file wmarketing_promotional_model.php */
