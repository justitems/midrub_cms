<?php
/**
 * User Inc
 *
 * PHP Version 7.3
 *
 * This file contains the function
 * to delete the user's data from Midrub Facebook Marketing
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */

 // Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');

if ( !function_exists('delete_user_from_facebook_marketing') ) {

    /**
     * The function delete_user_from_facebook_marketing deletes the user's records from Midrub Facebook Marketing
     * 
     * @param integer $user_id has the user's ID
     * 
     * @return void
     */
    function delete_user_from_facebook_marketing($user_id) {

        // Get codeigniter object instance
        $CI = get_instance();

        // Load Base Model
        $CI->load->ext_model( MIDRUB_BASE_PATH . 'models/', 'Base_model', 'base_model' );

        // The base model will be used to get all automatizations
        $get_automatizations = $CI->base_model->get_data_where(
            'whatsapp_automatizations',
            'automatization_id',
            array(
                'user_id' => $user_id
            )
        );  
        
        // Verify if automatizations exists
        if ( $get_automatizations ) {

            // List all automatizations
            foreach ( $get_automatizations as $automatization ) {

                // Delete the automatization
                $CI->base_model->delete('whatsapp_automatizations', array('automatization_id' => $automatization['automatization_id']));
                $CI->base_model->delete('whatsapp_automatizations_response', array('automatization_id' => $automatization['automatization_id']));
                $CI->base_model->delete('whatsapp_automatizations_categories', array('automatization_id' => $automatization['automatization_id']));
                $CI->base_model->delete('whatsapp_automatizations_history', array('automatization_id' => $automatization['automatization_id']));

            }

        }

        // The base model will be used to get all promotional's messages
        $get_messages = $CI->base_model->get_data_where(
            'whatsapp_promotional',
            'message_id',
            array(
                'user_id' => $user_id
            )
        );  
        
        // Verify if promotional messages exists
        if ( $get_messages ) {

            // List all promotional messages
            foreach ( $get_messages as $message ) {

                // Delete the promotional message
                $CI->base_model->delete('whatsapp_promotional', array('message_id' => $message['message_id']));
                $CI->base_model->delete('whatsapp_promotional_categories', array('message_id' => $message['message_id']));
                $CI->base_model->delete('whatsapp_promotional_history', array('message_id' => $message['message_id']));
                $CI->base_model->delete('whatsapp_promotional_message', array('message_id' => $message['message_id']));

            }

        }
        
    }

}

/* End of file user.php */