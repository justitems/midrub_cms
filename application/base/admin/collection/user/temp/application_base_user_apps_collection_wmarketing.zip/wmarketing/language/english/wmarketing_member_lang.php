<?php
$lang["wmarketing"] = "Whatsapp Marketing";
$lang["wmarketing_allow"] = "Allow Whatsapp Marketing";
$lang["wmarketing_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Whatsapp Marketing.";