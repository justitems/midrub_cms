<?php
$lang["wmarketing"] = "Wmarketing";
$lang["general"] = "General";
$lang["enable_app"] = "Enable App";
$lang["if_is_enabled_wmarketing"] = "You will be able to see it in the Plans page.";
$lang["if_is_enabled_wmarketing_plan"] = "If is enabled the marketing app will be available for this plan.";
$lang["wmarketing_promotional_messages"] = "Promotional Messages";
$lang["wmarketing_promotional_messages_description"] = "If is enabled for this plan users will be able to send Promotional Messages.";
