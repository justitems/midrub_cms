<?php
/**
 * General Inc
 *
 * PHP Version 7.3
 *
 * This files contains the hooks for
 * the Marketing's app
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */

 // Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * The public method add_hook registers a hook
 * 
 * @since 0.0.8.1
 */
add_hook(
    'delete_chatbot_category',
    function ($args) {

        // Verify if category's id exists
        if ( isset($args['category_id']) ) {

            // Get codeigniter object instance
            $CI = get_instance();

            //-----------------------------------------------------
            // Use the Base's model to delete the category's records
            //-----------------------------------------------------

            // If will be deleted all categories for a promotional message, the message will be available but categories won't be shown
            $CI->base_model->delete('whatsapp_promotional_categories', array('category_id' => $args['category_id']));

            // If will be deleted all automatization's categories, new messages won't be scheduled, but already scheduled will be sent
            $CI->base_model->delete('whatsapp_automatizations_categories', array('category_id' => $args['category_id']));

        }

    }

);

/* End of file general.php */