<?php

/**
 * Automatizations Helpers
 * 
 * PHP Version 7.3
 *
 * This file contains the class Automatizations
 * with methods to process the automatizations data
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Wmarketing\Helpers;

// Constats
defined('BASEPATH') or exit('No direct script access allowed');

/*
 * Automatizations class provides the methods to process the automatizations data
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
*/
class Automatizations
{

    /**
     * Class variables
     *
     * @since 0.0.8.1
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.1
     */
    public function __construct() {

        // Get codeigniter object instance
        $this->CI = &get_instance();

        // Load the FB Marketing Automatizations Model
        $this->CI->load->ext_model(MIDRUB_BASE_USER_APPS_WMARKETING . 'models/', 'Wmarketing_automatizations_model', 'wmarketing_automatizations_model');

        // Load the FB Marketing Subscribtions Model
        $this->CI->load->ext_model(MIDRUB_BASE_USER_APPS_WMARKETING . 'models/', 'Wmarketing_subscribers_model', 'wmarketing_subscribers_model');
        
        // Load the FB Marketing Categories Model
        $this->CI->load->ext_model( MIDRUB_BASE_USER_APPS_WMARKETING . 'models/', 'Wmarketing_categories_model', 'wmarketing_categories_model' );

        // Load Base Model
        $this->CI->load->ext_model( MIDRUB_BASE_PATH . 'models/', 'Base_model', 'base_model' );

    }

    //-----------------------------------------------------
    // Main class's methods
    //-----------------------------------------------------

    /**
     * The public method save_automatization saves an automatization
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function save_automatization()
    {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->CI->form_validation->set_rules('time', 'Time', 'trim');
            $this->CI->form_validation->set_rules('categories', 'Categories', 'trim');
            $this->CI->form_validation->set_rules('response_type', 'Response Type', 'trim');
            $this->CI->form_validation->set_rules('body', 'Body', 'trim');

            // Get data
            $name = $this->CI->input->post('name', TRUE);
            $time = $this->CI->input->post('time', TRUE);
            $categories = $this->CI->input->post('categories', TRUE);
            $response_type = $this->CI->input->post('response_type', TRUE);
            $body = $this->CI->input->post('body', TRUE);

            // Verify if the submitted data is correct
            if ($this->CI->form_validation->run() !== false) {

                // Verify if categories exists
                if ($categories) {

                    // All categories array
                    $all_categories = array();

                    // List all categories
                    foreach ($categories as $category) {

                        // Category should be numeric
                        if (is_numeric($category)) {

                            // Use the base model to verify if user has this category
                            $get_category = $this->CI->base_model->get_data_where(
                                'chatbot_categories',
                                'category_id',
                                array(
                                    'category_id' => $category,
                                    'user_id' => $this->CI->user_id
                                )
                            );

                            // Verify if category exists
                            if ($get_category) {

                                // Add category to list
                                $all_categories[] = $category;
                            }

                        }
                        
                    }

                    // Verify if at least one valid category was found
                    if (!$all_categories) {

                        // Prepare error response
                        $data = array(
                            'success' => FALSE,
                            'message' => $this->CI->lang->line('wmarketing_please_select_one_category')
                        );

                        // Display error response
                        echo json_encode($data);
                        exit();
                    }

                    // Try to create the automatization's parameters
                    $automatization = array(
                        'user_id' => $this->CI->user_id,
                        'name' => $name,
                        'time' => $time,
                        'created' => time()
                    );

                    // Save Automatization's parameters by using the Base's Model
                    $automatization_id = $this->CI->base_model->insert('whatsapp_automatizations', $automatization);

                    // Verify if the automatization was saved
                    if ($automatization_id) {

                        // Try to create the automatization's response
                        $response = array(
                            'automatization_id' => $automatization_id,
                            'type' => $response_type
                        );

                        // Verify what kind of response has the automatization's response
                        $response['body'] = $body;

                        // Save Automatization's response by using the Base's Model
                        $response_id = $this->CI->base_model->insert('whatsapp_automatizations_response', $response);

                        // Verify if the response was saved
                        if ( $response_id ) {

                            // Count categories
                            $count = 0;

                            // List all categories
                            foreach ($all_categories as $category_id) {

                                // Prepare the Category
                                $category = array(
                                    'automatization_id' => $automatization_id,
                                    'category_id' => $category_id
                                );

                                // Save the Category
                                if ($this->CI->base_model->insert('whatsapp_automatizations_categories', $category)) {
                                    $count++;
                                }

                            }

                            // Verify if at least one category was saved
                            if ( $count > 0 ) {

                                // Prepare success response
                                $data = array(
                                    'success' => TRUE,
                                    'message' => $this->CI->lang->line('wmarketing_automatization_was_saved')
                                );

                                // Display success response
                                echo json_encode($data);
                                exit();

                            } else {

                                // Delete the automatization
                                $this->CI->base_model->delete('whatsapp_automatizations', array('automatization_id' => $automatization_id));

                                // Delete the automatization's response
                                $this->CI->base_model->delete('whatsapp_automatizations_response', array('response_id' => $response_id));

                            }

                        } else {

                            // Delete the automatization
                            $this->CI->base_model->delete('whatsapp_automatizations', array('automatization_id' => $automatization_id) );

                        }

                    }
                    
                } else {

                    // Prepare error response
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('wmarketing_please_select_one_category')
                    );

                    // Display error response
                    echo json_encode($data);
                    exit();

                }

            }

        }

        // Prepare error response
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('wmarketing_automatization_was_not_saved')
        );

        // Display error response
        echo json_encode($data);

    }

    /**
     * The public method update_automatization updates an automatization
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */ 
    public function update_automatization() {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('automatization_id', 'Automatization ID', 'trim|numeric|required');
            $this->CI->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->CI->form_validation->set_rules('time', 'Time', 'trim');
            $this->CI->form_validation->set_rules('categories', 'Categories', 'trim');
            $this->CI->form_validation->set_rules('response_type', 'Response Type', 'trim');
            $this->CI->form_validation->set_rules('message', 'Message', 'trim');

            // Get data
            $automatization_id = $this->CI->input->post('automatization_id', TRUE);
            $name = $this->CI->input->post('name', TRUE);
            $time = $this->CI->input->post('time', TRUE);
            $categories = $this->CI->input->post('categories', TRUE);
            $response_type = $this->CI->input->post('response_type', TRUE);
            $message = $this->CI->input->post('message', TRUE);

            // Verify if the submitted data is correct
            if ($this->CI->form_validation->run() !== false) {

                // Use the base model for a simply sql query
                $get_automatization = $this->CI->base_model->get_data_where(
                    'whatsapp_automatizations',
                    'automatization_id',
                    array(
                        'automatization_id' => $automatization_id,
                        'user_id' => $this->CI->user_id
                    )
                );

                // Verify if the automatization is of the current user
                if ( $get_automatization ) {

                    // Prepare the automatization
                    $automatization_data = array(
                        'name' => $name
                    );

                    // Verify if time exists
                    if ( is_numeric($time) && ( $time > 0 && $time < 11 ) ) {

                        // Set time
                        $automatization_data['time'] = $time;

                    } else {

                        // Set time
                        $automatization_data['time'] = '0';
                        
                    }

                    // Try to update the automatization
                    $this->CI->base_model->update('whatsapp_automatizations', array('automatization_id' => $automatization_id), $automatization_data);

                    // Use the base model for a simply sql query
                    $get_updated_automatization = $this->CI->base_model->get_data_where(
                        'whatsapp_automatizations',
                        '*',
                        array(
                            'automatization_id' => $automatization_id,
                            'user_id' => $this->CI->user_id
                        )
                    );

                    // Very if the automatization was updated
                    if ( ($get_updated_automatization[0]['name'] === $automatization_data['name']) && ($get_updated_automatization[0]['time'] === $automatization_data['time']) ) {

                        // Delete the automatization's response
                        $this->CI->base_model->delete('whatsapp_automatizations_response', array('automatization_id' => $automatization_id));

                        // Verify which kind of response has the automatization
                        switch ( $response_type ) {

                            case '1':

                                // Try to create the automatization's response
                                $response = array(
                                    'automatization_id' => $automatization_id,
                                    'body' => $message,
                                    'type' => $response_type
                                );

                                // Save automatization's response by using the Base's Model
                                $response_id = $this->CI->base_model->insert('whatsapp_automatizations_response', $response);

                                // If automatization's response wasn't saved notify the user
                                if ( !$response_id ) {

                                    // Prepare the error message
                                    $data = array(
                                        'success' => FALSE,
                                        'message' => $this->CI->lang->line('wmarketing_automatization_was_updated_successfully_without_response')
                                    );

                                    // Display error message
                                    echo json_encode($data);
                                    exit();

                                }

                                break;

                        }

                        // Delete the automatization's categories
                        $this->CI->base_model->delete('whatsapp_automatizations_categories', array('automatization_id' => $automatization_id));

                        // Verify if categories exists
                        if ( $categories ) {

                            // Count categories
                            $count = 0;

                            // List all categories
                            foreach ($categories as $category_id) {

                                // Use the base model to verify if user is the owner of the category
                                $get_category = $this->CI->base_model->get_data_where(
                                    'chatbot_categories',
                                    '*',
                                    array(
                                        'category_id' => $category_id,
                                        'user_id' => $this->CI->user_id
                                    )
                                );

                                // Verify if the category and user exists
                                if ( $get_category ) {

                                    // Prepare the Category
                                    $category = array(
                                        'automatization_id' => $automatization_id,
                                        'category_id' => $category_id
                                    );

                                    // Save the Category
                                    if ($this->CI->base_model->insert('whatsapp_automatizations_categories', $category)) {
                                        $count++;
                                    }

                                }

                            }

                            // Verify if all categories were saved
                            if ( count($categories) > $count ) {

                                // Prepare the error message
                                $data = array(
                                    'success' => FALSE,
                                    'message' => $this->CI->lang->line('wmarketing_automatization_was_updated_successfully_without_categories')
                                );

                                // Display error message
                                echo json_encode($data);
                                exit();
                                
                            }

                        }

                        // Prepare the success message
                        $data = array(
                            'success' => TRUE,
                            'message' => $this->CI->lang->line('wmarketing_automatization_was_updated')
                        );

                        // Display success message
                        echo json_encode($data);
                        exit();

                    }

                } else {

                    // Prepare error response
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('wmarketing_you_are_not_automatization_owner')
                    );

                    // Display error response
                    echo json_encode($data);
                    exit();
                    
                }

            }

        }

        // Prepare error response
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('wmarketing_automatization_was_not_updated')
        );

        // Display error response
        echo json_encode($data);
        
    }

    /**
     * The public method load_automatizations loads automatizations
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */ 
    public function load_automatizations() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('key', 'Key', 'trim');
            $this->CI->form_validation->set_rules('page', 'Page', 'trim');

            // Get data
            $key = $this->CI->input->post('key', TRUE);
            $page = $this->CI->input->post('page', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare the false response
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('wmarketing_no_automatizations_found')
                );

                // Display the false response
                echo json_encode($data);
                
            } else {

                // If $page is false, set 1
                if (!$page) {
                    $page = 1;
                }

                // Set the limit
                $limit = 10;
                $page--;

                // Use the base model for a simply sql query
                $get_automatizations = $this->CI->base_model->get_data_where(
                    'whatsapp_automatizations',
                    'automatization_id, name',
                    array(
                        'user_id' => $this->CI->user_id
                    ),
                    array(),
                    array('name' => $this->CI->db->escape_like_str($key)),
                    array(),
                    array(
                        'order' => array('automatization_id', 'desc'),
                        'start' => ($page * $limit),
                        'limit' => $limit
                    )
                );

                // Verify if automatizations exists
                if ( $get_automatizations ) {

                    // Get total number of automatizations with base model
                    $total = $this->CI->base_model->get_data_where(
                        'whatsapp_automatizations',
                        'COUNT(automatization_id) AS total',
                        array(
                            'user_id' => $this->CI->user_id
                        ),
                        array(),
                        array('name' => $this->CI->db->escape_like_str($key)),
                        array(),
                        array()
                    );

                    // Prepare the response
                    $data = array(
                        'success' => TRUE,
                        'automatizations' => $get_automatizations,
                        'total' => $total[0]['total'],
                        'page' => ($page + 1)
                    );

                    // Display the response
                    echo json_encode($data);

                } else {

                    // Prepare the false response
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('wmarketing_no_automatizations_found')
                    );

                    // Display the false response
                    echo json_encode($data);

                }
                
            }
            
        }
        
    }

    /**
     * The public method delete_automatizations deletes automatizations
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */ 
    public function delete_automatizations() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('automatizations', 'automatizations', 'trim');
            
            // Get data
            $automatizations = $this->CI->input->post('automatizations');

            // Verify if request is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Default count
                $count = 0;

                // List all automatizations
                foreach ( $automatizations as $automatization ) {

                    // Verify if the automatization's id is numeric
                    if (is_numeric($automatization[1])) {

                        // Try to delete automatization
                        if ( $this->CI->base_model->delete('whatsapp_automatizations', array('automatization_id' => $automatization[1], 'user_id' => $this->CI->user_id)) ) {

                            // Delete the automatization's response
                            $this->CI->base_model->delete('whatsapp_automatizations_response', array('automatization_id' => $automatization[1]) );

                            // Delete the automatization's categories
                            $this->CI->base_model->delete('whatsapp_automatizations_categories', array('automatization_id' => $automatization[1]) );

                            // Delete the automatization's history
                            $this->CI->base_model->delete('whatsapp_automatizations_history', array('automatization_id' => $automatization[1]) );                            

                            // Increase count
                            $count++;

                        }

                    }

                }

                if ( $count ) {

                    $data = array(
                        'success' => TRUE,
                        'message' => $count . $this->CI->lang->line('wmarketing_automatizations_were_deleted')
                    );

                    echo json_encode($data);

                } else {

                    $data = array(
                        'success' => FALSE,
                        'message' => '0' . $this->CI->lang->line('wmarketing_automatizations_were_deleted')
                    );

                    echo json_encode($data);

                }
                
                exit();
                
            }
            
        }
        
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('wmarketing_error_occurred')
        );

        echo json_encode($data);
        
    }

    /**
     * The public method send_automatizations sends automatizations
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function send_automatizations() {

        // Get subscribtions which should receive a message
        $get_subscribers = $this->CI->wmarketing_subscribers_model->get_subscribers_for_automatizations();

        // Verify if subscribers exists
        if ( $get_subscribers ) {

            // Will be processed only one user per request
            // Get all categories of the current subscriber
            $get_categories = $this->CI->wmarketing_categories_model->get_subscriber_categories( $get_subscribers[0]['subscriber_id'] );

            // Verify if categories exists
            if ( $get_categories ) {

                // List all categories
                foreach ( $get_categories as $get_category ) {

                    // Get automatization by user's ID and category's ID
                    $automatization = $this->CI->wmarketing_automatizations_model->get_automatization_by_category_id( $get_subscribers[0]['user_id'], $get_category['category_id'] );

                    // Verify if automatization was found
                    if ( $automatization ) {

                        // Default time
                        $time = 0;

                        // Set the time if is not default
                        switch ( $automatization[0]['time'] ) {

                            case '1':

                                $time = 3600;

                                break;

                            case '2':

                                $time = 7200;

                                break;  
                                
                            case '3':

                                $time = 10800;

                                break; 
                                
                            case '4':

                                $time = 18000;

                                break; 
                                
                            case '5':

                                $time = 25200;

                                break;
                                
                            case '6':

                                $time = 36000;

                                break; 
                                
                            case '7':

                                $time = 43200;

                                break;
                                
                            case '8':

                                $time = 54000;

                                break;       
                                
                            case '9':

                                $time = 72000;

                                break; 
                                
                            case '10':

                                $time = 86000;

                                break;     

                        }

                        // Set total time
                        $total = time() + $time;

                        // Schedule automatization
                        $schedule = array(
                            'user_id' => $get_subscribers[0]['user_id'],
                            'page_id' => $get_subscribers[0]['page_id'],
                            'automatization_id' => $automatization[0]['automatization_id'],
                            'subscriber_id' => $get_subscribers[0]['subscriber_id'],
                            'response' => $automatization[0]['body'],
                            'type' => $automatization[0]['type'],
                            'status' => 2,
                            'scheduled' => $total,
                            'created' => time()
                        );

                        // Save the automatization's history
                        $this->CI->wmarketing_subscribers_model->save_automatization_history($schedule);

                        break;

                    }

                }

            }

        }
        
    }

    /**
     * The public method scheduled_automatizations processes a scheduled automatization
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function scheduled_automatizations() {

        // Get one scheduled automatization
        $scheduled_automatization = $this->CI->wmarketing_automatizations_model->get_scheduled_automatization();

        // Verify if the automatization exists
        if ( $scheduled_automatization ) {

            // Prepare the url
            $url = 'https://api.twilio.com/2010-04-01/Accounts/' . $scheduled_automatization[0]['token'] . '/Messages.json';

            // Set the params
            $params = array(
                'To' => 'whatsapp:' . $scheduled_automatization[0]['name'],
                'From' => 'whatsapp:' . $scheduled_automatization[0]['user_name'],
                'Body' => $scheduled_automatization[0]['response']
            );

            // Request for phone numbers
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_TIMEOUT, 30);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
            curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
            curl_setopt($curl, CURLOPT_USERPWD, $scheduled_automatization[0]['token'] . ':' . $scheduled_automatization[0]['secret']);
            $response = json_decode(curl_exec($curl), true);
            curl_close($curl);

            // Verify if response wasn't sent successfully
            if ( isset($response['message']) ) {

                // Save the error
                $this->CI->base_model->update('whatsapp_automatizations_history', array(
                    'history_id' => $scheduled_automatization[0]['history_id']
                ), array(
                    'error' => $this->CI->security->xss_clean($response['message']),
                    'status' => 0
                ));

            } else {

                // Update the status
                $this->CI->base_model->update('whatsapp_automatizations_history', array(
                    'history_id' => $scheduled_automatization[0]['history_id']
                ), array(
                    'status' => 1
                ));
                
            }

        }
        
    }

    /**
     * The public method automatization_activity_graph provides information to generate a graph 
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */ 
    public function automatization_activity_graph() {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('automatization_id', 'Automatization ID', 'trim|numeric|required');

            // Get data
            $automatization_id = $this->CI->input->post('automatization_id', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Loads reply's activity for graph
                $activities = $this->CI->wmarketing_automatizations_model->automatization_activity_graph($this->CI->user_id, $automatization_id);

                // Verify if activity exists
                if ( $activities ) {

                    // Prepare the success response
                    $data = array(
                        'success' => TRUE,
                        'activities' => $activities,
                        'words' => array(
                            'number_activities' => $this->CI->lang->line('wmarketing_number_activities')
                        )
                    );

                    // Display the success response
                    echo json_encode($data);
                    exit();

                }

            }

        }

        // Prepare the false response
        $data = array(
            'success' => FALSE,
            'words' => array(
                'number_activities' => $this->CI->lang->line('wmarketing_number_activities')
            )
        );

        // Display the false response
        echo json_encode($data);
        
    }
    
}

/* End of file automatizations.php */
