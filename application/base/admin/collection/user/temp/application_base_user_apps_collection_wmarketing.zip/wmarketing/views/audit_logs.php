<section class="wmarketing-page" data-csrf-name="<?php echo $this->security->get_csrf_token_name(); ?>" data-csrf-hash="<?php echo $this->security->get_csrf_hash(); ?>">
    <div class="row">
        <div class="col-xl-2 offset-xl-1 theme-box">
            <?php get_the_file(MIDRUB_BASE_USER_APPS_WMARKETING . 'views/menu.php'); ?>
        </div>
        <div class="col-xl-8">
            <div class="row clean">
                <div class="col-12 col-xl-4">
                    <div class="audit-small-widget theme-box">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php echo $this->lang->line('wmarketing_total_messages'); ?>
                            </div>
                            <div class="panel-body p-3">
                                <div class="row">
                                    <div class="col-6">
                                        <p>
                                            <?php echo htmlspecialchars($total_messages); ?>
                                        </p>
                                    </div>
                                    <div class="col-6 text-right">
                                        <i class="lni-facebook-messenger"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-xl-4">
                    <div class="audit-small-widget theme-box">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php echo $this->lang->line('wmarketing_subscribers'); ?>
                            </div>
                            <div class="panel-body p-3">
                                <div class="row">
                                    <div class="col-6">
                                        <p>
                                            <?php echo htmlspecialchars($total_subscribers); ?>
                                        </p>
                                    </div>
                                    <div class="col-6 text-right">
                                        <i class="lni-users"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-xl-4">
                    <div class="audit-small-widget theme-box">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php echo $this->lang->line('wmarketing_whatsapp_numbers'); ?>
                            </div>
                            <div class="panel-body p-3 text-center">
                                <div class="row">
                                    <div class="col-6">
                                        <p>
                                            <?php echo htmlspecialchars($total_numbers); ?>
                                        </p>
                                    </div>
                                    <div class="col-6 text-right">
                                        <i class="lni-whatsapp"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clean">
                <div class="col-12">
                    <div class="audit-large-widget theme-box">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-6 col-lg-8">
                                        <i class="lni-stats-up"></i>
                                        <?php echo $this->lang->line('wmarketing_messages_stats'); ?>
                                    </div>
                                    <div class="col-6 col-lg-4">
                                        <div class="dropdown dropdown-suggestions">
                                            <button class="btn btn-secondary dropdown-toggle wmarketing-select-stats-whatsapp-number btn-select" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <?php echo $this->lang->line('wmarketing_all_whatsapp_numbers'); ?>
                                            </button>
                                            <div class="dropdown-menu marketing-suggestions-dropdown" aria-labelledby="dropdownMenuButton" x-placement="bottom-start">
                                                <div class="card">
                                                    <div class="card-head">
                                                        <input type="text" class="wmarketing-search-for-stats-whatsapp-number" placeholder="<?php echo $this->lang->line('wmarketing_search_whatsapp_numbers'); ?>">
                                                    </div>
                                                    <div class="card-body">
                                                        <ul class="list-group wmarketing-stats-pages-list">
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body p-3">
                                <canvas id="messages-stats-chart" height="400"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clean">
                <div class="col-12">
                    <div class="audit-large-widget theme-box">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-6 col-lg-8">
                                        <i class="lni-alarm-clock"></i>
                                        <?php echo $this->lang->line('wmarketing_automatizations_popularity'); ?>
                                    </div>
                                    <div class="col-6 col-lg-4">
                                        <div class="dropdown dropdown-suggestions">
                                            <button class="btn btn-secondary dropdown-toggle wmarketing-select-keywords-whatsapp-number btn-select" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <?php echo $this->lang->line('wmarketing_all_whatsapp_numbers'); ?>
                                            </button>
                                            <div class="dropdown-menu marketing-suggestions-dropdown" aria-labelledby="dropdownMenuButton" x-placement="bottom-start">
                                                <div class="card">
                                                    <div class="card-head">
                                                        <input type="text" class="wmarketing-search-for-keywords-whatsapp-number" placeholder="<?php echo $this->lang->line('wmarketing_search_whatsapp_numbers'); ?>">
                                                    </div>
                                                    <div class="card-body">
                                                        <ul class="list-group wmarketing-keywords-stats-pages-list">
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">
                                                    <?php echo $this->lang->line('wmarketing_automatizations'); ?>
                                                </th>
                                                <th scope="col">
                                                    <?php echo $this->lang->line('wmarketing_response'); ?>
                                                </th>
                                                <th scope="col">
                                                    <?php echo $this->lang->line('wmarketing_sent'); ?>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="3">
                                                    <nav>
                                                        <ul class="pagination" data-type="popularity-messages">
                                                        </ul>
                                                    </nav>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>