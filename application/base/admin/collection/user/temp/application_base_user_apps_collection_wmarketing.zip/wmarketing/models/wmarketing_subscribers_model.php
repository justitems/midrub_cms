<?php
/**
 * Wmarketing Subscribers Model
 *
 * PHP Version 7.3
 *
 * Wmarketing_subscribers_model file contains the Wmarketing Subscribers Model
 *
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */

// Constants
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Wmarketing_subscribers_model class - operates the chatbot_subscribers table.
 *
 * @since 0.0.8.1
 * 
 * @category Social
 * @package  Midrub
 * @author   Scrisoft <asksyn@gmail.com>
 * @license  https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License
 * @link     https://www.midrub.com/
 */
class Wmarketing_subscribers_model extends CI_MODEL {
    
    /**
     * Class variables
     */
    private $table = 'chatbot_subscribers';

    /**
     * Initialise the model
     */
    public function __construct() {
        
        // Call the Model constructor
        parent::__construct();

        // Get the table
        $chatbot_subscribers = $this->db->table_exists('chatbot_subscribers');

        // Verify if the table exists
        if ( !$chatbot_subscribers ) {

            // Create the table
            $this->db->query('CREATE TABLE IF NOT EXISTS `chatbot_subscribers` (
                              `subscriber_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `user_id` int(11) NOT NULL,
                              `page_id` bigint(20) NOT NULL,
                              `network_name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                              `net_id` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                              `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                              `location` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                              `created` varchar(30) NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
        }

        // Get the table
        $chatbot_subscribers_categories = $this->db->table_exists('chatbot_subscribers_categories');

        // Verify if the table exists
        if ( !$chatbot_subscribers_categories ) {

            // Create the table
            $this->db->query('CREATE TABLE IF NOT EXISTS `chatbot_subscribers_categories` (
                              `id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `subscriber_id` bigint(20) NOT NULL,
                              `category_id` bigint(20) NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
        }

        // Get the table
        $chatbot_subscribers_history = $this->db->table_exists('chatbot_subscribers_history');

        // Verify if the table exists
        if ( !$chatbot_subscribers_history ) {

            // Create the table
            $this->db->query('CREATE TABLE IF NOT EXISTS `chatbot_subscribers_history` (
                              `history_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `user_id` int(11) NOT NULL,
                              `page_id` bigint(20) NOT NULL,
                              `reply_id` bigint(20) NOT NULL,
                              `subscriber_id` bigint(20) NOT NULL,
                              `question`  VARBINARY(4000) NOT NULL,
                              `response`  VARBINARY(4000) NOT NULL,
                              `error`  VARBINARY(4000) NOT NULL,
                              `type` tinyint(1) NOT NULL,
                              `source` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                              `created` varchar(30) NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
        }

        // Get the table
        $whatsapp_automatizations_history = $this->db->table_exists('whatsapp_automatizations_history');

        // Verify if the table exists
        if ( !$whatsapp_automatizations_history ) {

            // Create the table
            $this->db->query('CREATE TABLE IF NOT EXISTS `whatsapp_automatizations_history` (
                              `history_id` bigint(20) AUTO_INCREMENT PRIMARY KEY,
                              `user_id` int(11) NOT NULL,
                              `page_id` bigint(20) NOT NULL,
                              `automatization_id` bigint(20) NOT NULL,
                              `subscriber_id` bigint(20) NOT NULL,
                              `response`  VARBINARY(4000) NOT NULL,
                              `error`  VARBINARY(4000) NOT NULL,
                              `type` tinyint(1) NOT NULL,
                              `status` tinyint(1) NOT NULL,
                              `source` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
                              `scheduled` varchar(30) NOT NULL,
                              `created` varchar(30) NOT NULL
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;');
        }
        
        // Set the tables value
        $this->tables = $this->config->item('tables', $this->table);
        
    }

    /**
     * The public method save_automatization_history saves an automatization's history
     *
     * @param array $args contains the history's data
     * 
     * @return integer with last inserted ID or boolean false
     */
    public function save_automatization_history( $args ) {
        
        // Insert data
        $this->db->insert('whatsapp_automatizations_history', $args);
        
        if ( $this->db->affected_rows() ) {
            
            // Return last inserted ID
            return $this->db->insert_id();
            
        } else {
            
            return false;
            
        }
        
    }

    /**
     * The public method get_subscribers_for_automatizations gets the last subscritions which should receive a message
     * 
     * @return array with subscribtions or boolean false
     */
    public function get_subscribers_for_automatizations() {
        
        // Get subscribers which are new and never have got an automatization's message
        $this->db->select('chatbot_subscribers.*');
        $this->db->from('chatbot_subscribers');
        $this->db->join('whatsapp_automatizations_history', 'chatbot_subscribers.subscriber_id=whatsapp_automatizations_history.subscriber_id', 'LEFT');
        $this->db->where(array(
            'whatsapp_automatizations_history.subscriber_id' => NULL
        ));
        $query = $this->db->get();
        
        // Verify if data exists
        if ( $query->num_rows() > 0 ) {
            
            // Return data
            return $query->result_array();
            
        } else {
            
            return false;
            
        }
        
    }

    /**
     * The public method get_subscribers_by_categories gets the subscribers number by categories
     * 
     * @param array $categories contains an array with categories
     * 
     * @return integer with number or boolean false
     */
    public function get_subscribers_by_categories($categories) {
        
        // Get subscribers
        $this->db->select('COUNT(chatbot_subscribers.subscriber_id) AS total');
        $this->db->from('chatbot_subscribers_categories');
        $this->db->join('chatbot_subscribers', 'chatbot_subscribers_categories.subscriber_id=chatbot_subscribers.subscriber_id', 'LEFT');
        $this->db->where_in('chatbot_subscribers_categories.category_id', $categories);
        $this->db->group_by('chatbot_subscribers.subscriber_id');
        $query = $this->db->get();
        
        // Verify if data exists
        if ( $query->num_rows() > 0 ) {
            
            // Return number
            return $query->num_rows();
            
        } else {
            
            return false;
            
        }
        
    }
    
}

/* End of file wmarketing_subscribers_model.php */