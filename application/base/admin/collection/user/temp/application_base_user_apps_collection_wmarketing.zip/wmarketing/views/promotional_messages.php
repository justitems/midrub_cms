<section class="wmarketing-page">
    <div class="row">
        <div class="col-xl-2 offset-xl-1 theme-box">
            <?php get_the_file(MIDRUB_BASE_USER_APPS_WMARKETING . 'views/menu.php'); ?>
        </div>
        <div class="col-xl-8">
            <div class="wmarketing-list theme-box">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-8">
                                <i class="lni-bullhorn"></i>
                                <?php echo $this->lang->line('wmarketing_promotional_messages'); ?>
                            </div>
                            <div class="col-4">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-primary theme-background-green" data-toggle="modal" data-target="#create-new-promotional-message">
                                        <i class="lni-alarm"></i>
                                        <?php echo $this->lang->line('wmarketing_new_message'); ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-12">
                                <?php echo form_open('user/app/marketing', array('class' => 'search-promotional-messages', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <i class="icon-magnifier"></i>
                                    </div>
                                    <input type="text" class="form-control promotional-messages-key" placeholder="<?php echo $this->lang->line('wmarketing_search_for_messages'); ?>">
                                    <div class="input-group-append">
                                        <button type="button" class="btn input-group-text cancel-promotional-messages-search">
                                            <i class="icon-close"></i>
                                        </button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="promotional-messages-management">
                                    <div class="checkbox-option-select">
                                        <input id="all-promotional-messages-select" name="all-promotional-messages-select" type="checkbox">
                                        <label for="all-promotional-messages-select"></label>
                                    </div>
                                    <button type="button" class="btn btn-sm btn-primary theme-background-white delete-promotional-messages">
                                        <i class="icon-trash"></i>
                                        <?php echo $this->lang->line('wmarketing_delete'); ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <ul class="promotional-messages-list">
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <nav>
                            <ul class="pagination" data-type="promotional-messages">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Create New Promotional Message -->
<div class="modal fade" id="create-new-promotional-message" tabindex="-1" role="dialog" aria-boostledby="create-new-promotional-message" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <?php echo $this->lang->line('wmarketing_create_new_promotional_message'); ?>
                </h2>
                <button type="button" class="close" data-dismiss="modal" aria-boost="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open('user/app/marketing', array('class' => 'wmarketing-create-promotional-message', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend>
                                <?php echo $this->lang->line('wmarketing_name'); ?>
                            </legend>
                            <div class="input-group">
                                <input type="text" class="form-control promotional-message-name" name="promotional-message-name" placeholder="<?php echo $this->lang->line('wmarketing_enter_promotional_message_name'); ?>" required>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend><?php echo $this->lang->line('wmarketing_time_interval'); ?></legend>
                            <p>
                                <i class="lni-alarm"></i>
                                <?php echo $this->lang->line('wmarketing_select_time_scheduling'); ?>
                            </p>
                            <div class="dropdown dropdown-time">
                                <button class="btn btn-secondary dropdown-toggle wmarketing-select-time btn-select" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-id="0">
                                    <?php echo $this->lang->line('wmarketing_immediately'); ?>
                                </button>
                                <div class="dropdown-menu marketing-time-dropdown" aria-labelledby="dropdownMenuButton" x-placement="bottom-start">
                                    <div class="card">
                                        <div class="card-body">
                                            <ul class="list-group">
                                                <li class="list-group-item">
                                                    <a href="#" data-id="1">
                                                        1 <?php echo $this->lang->line('wmarketing_hour'); ?>
                                                    </a>
                                                </li>
                                                <li class="list-group-item">
                                                    <a href="#" data-id="2">
                                                        2 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                    </a>
                                                </li>
                                                <li class="list-group-item">
                                                    <a href="#" data-id="3">
                                                        3 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                    </a>
                                                </li>
                                                <li class="list-group-item">
                                                    <a href="#" data-id="4">
                                                        5 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                    </a>
                                                </li>
                                                <li class="list-group-item">
                                                    <a href="#" data-id="5">
                                                        7 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                    </a>
                                                </li>
                                                <li class="list-group-item">
                                                    <a href="#" data-id="6">
                                                        10 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                    </a>
                                                </li>
                                                <li class="list-group-item">
                                                    <a href="#" data-id="7">
                                                        12 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                    </a>
                                                </li>
                                                <li class="list-group-item">
                                                    <a href="#" data-id="8">
                                                        15 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                    </a>
                                                </li>
                                                <li class="list-group-item">
                                                    <a href="#" data-id="9">
                                                        20 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                    </a>
                                                </li>
                                                <li class="list-group-item">
                                                    <a href="#" data-id="10">
                                                        24 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend>
                                <?php echo $this->lang->line('wmarketing_categories'); ?>
                            </legend>
                            <div class="row">
                                <div class="col-12">
                                    <p>
                                        <i class="lni-alarm"></i>
                                        <?php echo $this->lang->line('wmarketing_select_the_promo_category'); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 all-categories-list">

                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend><?php echo $this->lang->line('wmarketing_message'); ?></legend>
                            <p>
                                <i class="lni-alarm"></i>
                                <?php echo $this->lang->line('wmarketing_message_or_template_as_promotional_message'); ?>
                            </p>
                            <div class="row">
                                <div class="col-12">
                                    <div class="dropdown dropdown-suggestions">
                                        <button
                                            class="btn btn-secondary dropdown-toggle wmarketing-select-template-type btn-select"
                                            type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false" data-id="0">
                                            <?php echo $this->lang->line('wmarketing_text_auto_reply'); ?>
                                        </button>
                                        <div class="dropdown-menu chatbot-suggestions-dropdown"
                                            aria-labelledby="dropdownMenuButton" x-placement="bottom-start">
                                            <div class="card">
                                                <div class="card-body">
                                                    <ul class="nav nav-tabs list-group chatbot-suggestions-list">
                                                        <li class="list-group-item">
                                                            <a data-toggle="tab" href="#text-auto-reply" role="tab" aria-controls="text-auto-reply" aria-selected="true" data-id="0">
                                                                <?php echo $this->lang->line('wmarketing_text_auto_reply'); ?>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="text-auto-reply" role="tabpanel"
                                            aria-labelledby="text-auto-reply-tab">
                                            <div class="accordion" id="accordion">
                                                <div class="card">
                                                    <div class="card-header" id="headingOne">
                                                        <button class="btn btn-link" type="button"
                                                            data-toggle="collapse" data-target="#text-auto-reply-body"
                                                            aria-expanded="true" aria-controls="text-auto-reply-body">
                                                            <?php echo $this->lang->line('wmarketing_response_body'); ?>
                                                        </button>
                                                    </div>

                                                    <div id="text-auto-reply-body" class="collapse show"
                                                        aria-labelledby="text-auto-reply-body" data-parent="#accordion"
                                                        data-type="text-reply">
                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="col-12">
                                                                    <div class="form-group">
                                                                        <textarea class="form-control reply-text-message" rows="3" placeholder="<?php echo $this->lang->line('wmarketing_enter_text_response'); ?>"></textarea>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-right">
                        <fieldset>
                            <span class="selected-subscribers">
                            </span>
                            <button type="submit" class="btn btn-primary">
                                <i class="lni-save"></i>
                                <?php echo $this->lang->line('save'); ?>
                            </button>
                        </fieldset>
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>

<!-- Word list for JS !-->
<script language="javascript">
    var words = {
        please_enter_text_promotional: '<?php echo $this->lang->line('wmarketing_please_enter_text_promotional'); ?>',
        please_select_suggestion_group: '<?php echo $this->lang->line('wmarketing_please_select_suggestion_group'); ?>',
        please_select_promotional_messages: '<?php echo $this->lang->line('wmarketing_please_select_promotional_messages'); ?>',
        please_select_category: '<?php echo $this->lang->line('wmarketing_please_select_category'); ?>',
        immediately: '<?php echo $this->lang->line('wmarketing_immediately'); ?>',
        suggestions_groups: '<?php echo $this->lang->line('wmarketing_suggestions_groups'); ?>',
    };
</script>