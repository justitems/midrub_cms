<div class="wmarketing-menu-group">
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/wmarketing'); ?>" class="nav-link<?php echo !$this->input->get('p', TRUE)?' active show':''; ?>">
                <i class="lni-alarm-clock"></i>
                <?php echo $this->lang->line('wmarketing_automatizations'); ?>
            </a>
        </li>  
        <?php if ( plan_feature('app_wmarketing_promotional_message') ) { ?>
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/wmarketing?p=promotional-messages'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'promotional-messages')?' active show':''; ?>">
                <i class="lni-bullhorn"></i>
                <?php echo $this->lang->line('wmarketing_promotional_messages'); ?>
            </a>
        </li>
        <?php } ?>                          
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/wmarketing?p=subscribers'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'subscribers')?' active show':''; ?>">
                <i class="lni-users"></i>
                <?php echo $this->lang->line('wmarketing_subscribers'); ?>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/wmarketing?p=audit-logs'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'audit-logs')?' active show':''; ?>">
                <i class="lni-bar-chart"></i>
                <?php echo $this->lang->line('wmarketing_audit_logs'); ?>
            </a>
        </li>
    </ul>
</div>