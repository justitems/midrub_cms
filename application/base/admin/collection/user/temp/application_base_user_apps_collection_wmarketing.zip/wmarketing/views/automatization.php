<section class="wmarketing-page-automatization" data-automatization="<?php echo $automatization_id; ?>">
    <div class="row">
        <div class="col-12">
            <div class="theme-box new-automatization-top">
                <?php echo form_open('user/app/wmarketing', array('class' => 'save-automatization-form', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                <div class="row">
                    <div class="col-4 col-lg-8">
                        <input type="text" class="form-control automatization-name" placeholder="<?php echo $this->lang->line('wmarketing_enter_the_keywords'); ?>" value="<?php echo htmlspecialchars($name); ?>" required>
                    </div>
                    <div class="col-8 col-lg-4 text-right">
                        <div class="btn-group" role="group">
                            <button type="submit" class="btn btn-secondary theme-background-blue marketing-save-automatization">
                                <i class="lni-save"></i>
                                <?php echo $this->lang->line('save'); ?>
                            </button>
                        </div>
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div>
            <div class="automatization-categories">
                <div class="row">
                    <div class="col-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php
                                if ( isset($categories) ) {

                                    foreach ($categories as $category) {

                                        echo '<button class="btn btn-primary select-category" type="button" data-id="' . $category['category_id'] . '">'
                                                . '<i class="far fa-bookmark"></i>'
                                                . htmlspecialchars($category['name'])
                                            . '</button>';
                                    }
                                }
                                ?>
                                <button class="btn btn-success select-categories" type="button" data-toggle="collapse" data-target=".multi-collapse" aria-expanded="false" aria-controls="categories">
                                    <span>&#43;</span>
                                </button>
                            </div>
                            <div class="panel-body collapse multi-collapse" id="categories">
                                <div class="row row-eq-height">
                                    <div class="col-12 col-lg-4 col-xl-2">
                                        <button type="button" class="btn btn-secondary theme-color-black" data-toggle="modal" data-target="#categories-manager">
                                            <i class="icon-settings"></i>
                                            <?php echo $this->lang->line('wmarketing_manage_categories'); ?>
                                        </button>
                                    </div>
                                    <div class="col-12 col-lg-8 col-xl-10">
                                        <div class="row">
                                            <div class="col-12">
                                                <?php echo form_open('user/app/wmarketing', array('class' => 'search-categories', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <i class="icon-magnifier"></i>
                                                    </div>
                                                    <input type="text" class="form-control search-category" placeholder="<?php echo $this->lang->line('wmarketing_search_categories'); ?>">
                                                    <div class="input-group-append">
                                                        <button type="button" class="btn input-group-text cancel-categories-search">
                                                            <i class="icon-close"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                                <?php echo form_close(); ?>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12 all-categories-list">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="new-automatization-body">
                <div class="row">
                    <div class="col-12 col-lg-8 mb-4">
                        <div class="theme-box automatization-response">
                            <div class="row">
                                <div class="col-12">
                                    <fieldset>
                                        <legend><?php echo $this->lang->line('wmarketing_time_interval'); ?></legend>
                                        <p>
                                            <i class="lni-alarm"></i>
                                            <?php echo $this->lang->line('wmarketing_select_time_response'); ?>
                                        </p>
                                        <div class="dropdown dropdown-time">
                                            <button class="btn btn-secondary dropdown-toggle marketing-select-time btn-select" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-id="<?php echo $time; ?>">
                                                <?php echo $time_text; ?>
                                            </button>
                                            <div class="dropdown-menu marketing-time-dropdown" aria-labelledby="dropdownMenuButton" x-placement="bottom-start">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <ul class="list-group">
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="1">
                                                                    1 <?php echo $this->lang->line('wmarketing_hour'); ?>
                                                                </a>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="2">
                                                                    2 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                                </a>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="3">
                                                                    3 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                                </a>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="4">
                                                                    5 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                                </a>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="5">
                                                                    7 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                                </a>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="6">
                                                                    10 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                                </a>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="7">
                                                                    12 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                                </a>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="8">
                                                                    15 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                                </a>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="9">
                                                                    20 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                                </a>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <a href="#" data-id="10">
                                                                    24 <?php echo $this->lang->line('wmarketing_hours'); ?>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <fieldset>
                                        <legend><?php echo $this->lang->line('wmarketing_message'); ?></legend>
                                        <p>
                                            <i class="lni-alarm"></i>
                                            <?php echo $this->lang->line('wmarketing_text_reply_or_suggestions'); ?>
                                        </p>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="dropdown dropdown-suggestions">
                                                    <button
                                                        class="btn btn-secondary dropdown-toggle wmarketing-select-template-type btn-select"
                                                        type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                                        aria-haspopup="true" aria-expanded="false" data-id="0">
                                                        <?php echo $this->lang->line('wmarketing_text_auto_reply'); ?>
                                                    </button>
                                                    <div class="dropdown-menu chatbot-suggestions-dropdown"
                                                        aria-labelledby="dropdownMenuButton" x-placement="bottom-start">
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <ul class="nav nav-tabs list-group chatbot-suggestions-list">
                                                                    <li class="list-group-item">
                                                                        <a data-toggle="tab" href="#text-auto-reply" role="tab" aria-controls="text-auto-reply" aria-selected="true" data-id="0">
                                                                            <?php echo $this->lang->line('wmarketing_text_auto_reply'); ?>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="text-auto-reply" role="tabpanel"
                                                        aria-labelledby="text-auto-reply-tab">
                                                        <div class="accordion" id="accordion">
                                                            <div class="card">
                                                                <div class="card-header" id="headingOne">
                                                                    <button class="btn btn-link" type="button"
                                                                        data-toggle="collapse" data-target="#text-auto-reply-body"
                                                                        aria-expanded="true" aria-controls="text-auto-reply-body">
                                                                        <?php echo $this->lang->line('wmarketing_response_body'); ?>
                                                                    </button>
                                                                </div>

                                                                <div id="text-auto-reply-body" class="collapse show"
                                                                    aria-labelledby="text-auto-reply-body" data-parent="#accordion"
                                                                    data-type="text-reply">
                                                                    <div class="card-body">
                                                                        <div class="row">
                                                                            <div class="col-12">
                                                                                <div class="form-group">
                                                                                    <textarea class="form-control reply-text-message" rows="3" placeholder="<?php echo $this->lang->line('wmarketing_enter_text_response'); ?>"><?php echo $body; ?></textarea>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                        <div class="theme-box automatization-graph">
                            <div class="row">
                                <div class="col-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h3>
                                                <i class="lni-stats-up"></i>
                                                <?php echo $this->lang->line('wmarketing_active_last_month'); ?>
                                            </h3>
                                        </div>
                                        <div class="panel-body">
                                            <canvas id="automatization-stats-chart" height="400"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="theme-box automatization-users">
                            <div class="row">
                                <div class="col-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h3>
                                                <i class="lni-users"></i>
                                                <?php echo $this->lang->line('wmarketing_subscribers'); ?>
                                            </h3>
                                        </div>
                                        <div class="panel-body">
                                            <ul class="list-group subscribers-list">

                                            </ul>
                                        </div>
                                        <div class="panel-footer">
                                            <nav>
                                                <ul class="pagination" data-type="subscribers">
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Categories Manager -->
<div class="modal fade" id="categories-manager" tabindex="-1" role="dialog" aria-boostledby="categories-manager" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <?php echo $this->lang->line('wmarketing_manage_categories'); ?>
                </h2>
                <button type="button" class="close" data-dismiss="modal" aria-boost="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend><?php echo $this->lang->line('wmarketing_new_category'); ?></legend>
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <?php echo form_open('user/app/wmarketing', array('class' => 'wmarketing-create-category', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                                    <div class="input-group">
                                        <input type="text" class="form-control category-name" name="category-name" placeholder="<?php echo $this->lang->line('wmarketing_enter_category_name'); ?>">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-primary">
                                                <i class="lni-save"></i>
                                                <?php echo $this->lang->line('save'); ?>
                                            </button>
                                        </div>
                                    </div>
                                    <?php echo form_close(); ?>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend>
                                <?php echo $this->lang->line('wmarketing_all_categories'); ?>
                            </legend>
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <ul class="all-categories">
                                    </ul>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <fieldset class="fieldset-pagination">
                            <nav>
                                <ul class="pagination" data-type="categories">
                                </ul>
                            </nav>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Word list for JS !-->
<script language="javascript">
    var words = {
        please_enter_text_reply: '<?php echo $this->lang->line('wmarketing_please_enter_text_reply'); ?>',
        please_select_suggestion_group: '<?php echo $this->lang->line('wmarketing_please_select_suggestion_group'); ?>',
        please_select_automatizations: '<?php echo $this->lang->line('wmarketing_please_select_automatizations'); ?>',
        immediately: '<?php echo $this->lang->line('wmarketing_immediately'); ?>',
        suggestions_groups: '<?php echo $this->lang->line('wmarketing_suggestions_groups'); ?>',
    };
</script>