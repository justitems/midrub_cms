<section class="wmarketing-page-message" data-message="<?php echo $message_id; ?>" data-csrf-name="<?php echo $this->security->get_csrf_token_name(); ?>" data-csrf-hash="<?php echo $this->security->get_csrf_hash(); ?>">
    <div class="row">
        <div class="col-12">
            <div class="theme-box new-message-top">
                <div class="row">
                    <div class="col-12">
                        <input type="text" class="form-control message-name" placeholder="<?php echo $this->lang->line('wmarketing_enter_the_keywords'); ?>" value="<?php echo htmlspecialchars($name); ?>" required>
                    </div>
                </div>
            </div>
            <?php if (isset($categories)) { ?>
                <div class="message-categories">
                    <div class="row">
                        <div class="col-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <?php
                                        foreach ($categories as $category) {

                                            echo '<button class="btn btn-primary select-category" type="button" data-id="' . $category['category_id'] . '">'
                                                    . '<i class="far fa-bookmark"></i>'
                                                    . htmlspecialchars($category['name'])
                                                . '</button>';
                                        }
                                        ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
            <div class="new-message-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-12">
                                <div class="theme-box message-response">
                                    <div class="row">
                                        <div class="col-12">
                                            <fieldset>
                                                <legend><?php echo $this->lang->line('wmarketing_time_interval'); ?></legend>
                                                <p>
                                                    <?php echo $time_text; ?>
                                                </p>
                                            </fieldset>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <fieldset>
                                                <legend><?php echo $this->lang->line('wmarketing_message'); ?></legend>
                                                <div class="accordion" id="accordion">
                                                    <?php if ($type < 2) { ?>
                                                        <div class="card">
                                                            <div class="card-header" id="headingOne">
                                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#menu-text-reply" aria-expanded="true" aria-controls="menu-text-reply">
                                                                    <?php echo $this->lang->line('wmarketing_plain_text'); ?>
                                                                </button>
                                                            </div>

                                                            <div id="menu-text-reply" class="collapse show" aria-labelledby="menu-text-reply" data-parent="#accordion" data-type="text-reply">
                                                                <div class="card-body">
                                                                    <div class="row">
                                                                        <div class="col-12">
                                                                            <div class="form-group">
                                                                                <textarea class="form-control text-message" rows="3" placeholder="<?php echo $this->lang->line('wmarketing_enter_text_message'); ?>"><?php echo htmlspecialchars($body); ?></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php } else { ?>
                                                        <div class="card">
                                                            <div class="card-header" id="headingTwo">
                                                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#menu-suggestions" aria-expanded="true" aria-controls="menu-suggestions">
                                                                    <?php echo $this->lang->line('wmarketing_suggestions_groups'); ?>
                                                                </button>
                                                            </div>
                                                            <div id="menu-suggestions" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordion" data-type="suggestions-group">
                                                                <div class="card-body">
                                                                    <div class="row">
                                                                        <div class="col-12">
                                                                            <p>
                                                                                <i class="lni-line-spacing"></i>
                                                                                <?php echo ($group_name) ? $group_name : $this->lang->line('wmarketing_group_deleted'); ?>
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            </fieldset>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-12 col-xl-4">
                                <div class="promotional-small-widget theme-box">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <?php echo $this->lang->line('wmarketing_subscribers'); ?>
                                        </div>
                                        <div class="panel-body p-3">
                                            <div class="row">
                                                <div class="col-6">
                                                    <p>
                                                        <?php echo $sent_subscribers; ?>
                                                    </p>
                                                </div>
                                                <div class="col-6 text-right">
                                                    <i class="lni-users"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-4">
                                <div class="promotional-small-widget theme-box">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <?php echo $this->lang->line('wmarketing_success'); ?>
                                        </div>
                                        <div class="panel-body p-3">
                                            <div class="row">
                                                <div class="col-6">
                                                    <p>
                                                        <?php echo $sent_success; ?>
                                                    </p>
                                                </div>
                                                <div class="col-6 text-right">
                                                    <i class="lni-check-mark-circle"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-xl-4">
                                <div class="promotional-small-widget theme-box">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <?php echo $this->lang->line('wmarketing_error'); ?>
                                        </div>
                                        <div class="panel-body p-3 text-center">
                                            <div class="row">
                                                <div class="col-6">
                                                    <p>
                                                        <?php echo ($sent_subscribers - $sent_success); ?>
                                                    </p>
                                                </div>
                                                <div class="col-6 text-right">
                                                    <i class="lni-cross-circle"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="promotional-large-widget theme-box">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <div class="row">
                                                <div class="col-12">
                                                    <i class="lni-users"></i>
                                                    <?php echo $this->lang->line('wmarketing_subscribers'); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="panel-body">
                                            <ul class="list-group subscribers-list">
                                            </ul>
                                        </div>
                                        <div class="panel-footer">
                                            <nav>
                                                <ul class="pagination" data-type="subscribers">
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>