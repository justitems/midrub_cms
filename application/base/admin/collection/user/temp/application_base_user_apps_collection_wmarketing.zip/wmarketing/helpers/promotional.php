<?php
/**
 * Promotional Helpers
 * 
 * PHP Version 7.3
 *
 * This file contains the class Promotional
 * with methods to process the promotional messages
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Wmarketing\Helpers;

// Constats
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Promotional class provides the methods to process the promotional messages
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.1
*/
class Promotional {
    
    /**
     * Class variables
     *
     * @since 0.0.8.1
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.1
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();

        // Load the Wmarketing Subscribtions Model
        $this->CI->load->ext_model(MIDRUB_BASE_USER_APPS_WMARKETING . 'models/', 'Wmarketing_subscribers_model', 'wmarketing_subscribers_model');

        // Load the Wmarketing Promotional Model
        $this->CI->load->ext_model(MIDRUB_BASE_USER_APPS_WMARKETING . 'models/', 'Wmarketing_promotional_model', 'wmarketing_promotional_model');
        
    }

    //-----------------------------------------------------
    // Main class's methods
    //-----------------------------------------------------

    /**
     * The public method save_promotional_message saves promotional messages
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function save_promotional_message()
    {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->CI->form_validation->set_rules('time', 'Time', 'trim');
            $this->CI->form_validation->set_rules('categories', 'Categories', 'trim');
            $this->CI->form_validation->set_rules('response_type', 'Response Type', 'trim');
            $this->CI->form_validation->set_rules('body', 'Body', 'trim');

            // Get data
            $name = $this->CI->input->post('name', TRUE);
            $time = $this->CI->input->post('time', TRUE);
            $categories = $this->CI->input->post('categories', TRUE);
            $response_type = $this->CI->input->post('response_type', TRUE);
            $body = $this->CI->input->post('body', TRUE);

            // Verify if the submitted data is correct
            if ($this->CI->form_validation->run() !== false) {

                // Verify if categories exists
                if ( $categories ) {

                    // All categories array
                    $all_categories = array();

                    // List all categories
                    foreach ( $categories as $category ) {

                        // Category should be numeric
                        if ( is_numeric($category) ) {

                            // Use the base model to verify if user has this category
                            $get_category = $this->CI->base_model->get_data_where(
                                'chatbot_categories',
                                'category_id',
                                array(
                                    'category_id' => $category,
                                    'user_id' => $this->CI->user_id
                                )
                            );

                            // Verify if category exists
                            if ( $get_category ) {

                                // Add category to list
                                $all_categories[] = $category;
                                
                            }

                        }
                        
                    }

                    // Verify if at least one valid category was found
                    if ( !$all_categories ) {

                        // Prepare error response
                        $data = array(
                            'success' => FALSE,
                            'message' => $this->CI->lang->line('wmarketing_please_select_one_category')
                        );

                        // Display error response
                        echo json_encode($data);
                        exit();
                    }

                    // Try to create the promotional's parameters
                    $promotional_params = array(
                        'user_id' => $this->CI->user_id,
                        'name' => $name,
                        'status' => 2,
                        'created' => time()
                    );

                    // Verify if time exists
                    if ( is_numeric($time) && ( $time > 0 && $time < 11 ) ) {

                        // Set the scheduled's time
                        switch ( $time ) {

                            case '1':

                                $promotional_params['scheduled'] = time() + 3600;

                                break;

                            case '2':

                                $promotional_params['scheduled'] = time() + 7200;

                                break;  
                                
                            case '3':

                                $promotional_params['scheduled'] = time() + 10800;

                                break; 
                                
                            case '4':

                                $promotional_params['scheduled'] = time() + 18000;

                                break; 
                                
                            case '5':

                                $promotional_params['scheduled'] = time() + 25200;

                                break;
                                
                            case '6':

                                $promotional_params['scheduled'] = time() + 36000;

                                break; 
                                
                            case '7':

                                $promotional_params['scheduled'] = time() + 43200;

                                break;
                                
                            case '8':

                                $promotional_params['scheduled'] = time() + 54000;

                                break;       
                                
                            case '9':

                                $promotional_params['scheduled'] = time() + 72000;

                                break; 
                                
                            case '10':

                                $promotional_params['scheduled'] = time() + 86000;

                                break;     

                        }

                    } else {

                        // Set scheduled time
                        $promotional_params['scheduled'] = time();
                        
                    }

                    // Save promotional's parameters by using the Base's Model
                    $promotional = $this->CI->base_model->insert('whatsapp_promotional', $promotional_params);

                    // Verify if the promotional was saved
                    if ( $promotional ) {

                        // Try to create the promotional's message
                        $message_params = array(
                            'message_id' => $promotional,
                            'type' => $response_type
                        );

                        // Set the promotional's message
                        $message_params['body'] = $body;

                        // Save promotional's message by using the Base's Model
                        $id = $this->CI->base_model->insert('whatsapp_promotional_message', $message_params);

                        // Verify if the response was saved
                        if ( $id ) {

                            // Count categories
                            $count = 0;

                            // List all categories
                            foreach ($all_categories as $category_id) {

                                // Prepare the Category
                                $category = array(
                                    'message_id' => $promotional,
                                    'category_id' => $category_id
                                );

                                // Save the Category
                                if ($this->CI->base_model->insert('whatsapp_promotional_categories', $category)) {
                                    $count++;
                                }

                            }

                            // Verify if at least one category was saved
                            if ( $count > 0 ) {

                                // Prepare success response
                                $data = array(
                                    'success' => TRUE,
                                    'message' => $this->CI->lang->line('wmarketing_promotional_was_saved')
                                );

                                // Display success response
                                echo json_encode($data);
                                exit();

                            } else {

                                // Delete the promotional
                                $this->CI->base_model->delete('whatsapp_promotional', array('message_id' => $promotional));

                                // Delete the promotional's response
                                $this->CI->base_model->delete('whatsapp_promotional_message', array('id' => $id));

                            }

                        } else {

                            // Delete the promotional
                            $this->CI->base_model->delete('whatsapp_promotional', array('message_id' => $promotional) );

                        }

                    }
                    
                } else {

                    // Prepare error response
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('wmarketing_please_select_one_category')
                    );

                    // Display error response
                    echo json_encode($data);
                    exit();

                }

            }

        }

        // Prepare error response
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('wmarketing_promotional_was_not_saved')
        );

        // Display error response
        echo json_encode($data);

    }

    /**
     * The public method load_promotional_messages loads promotional messages
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */ 
    public function load_promotional_messages() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('key', 'Key', 'trim');
            $this->CI->form_validation->set_rules('page', 'Page', 'trim');

            // Get data
            $key = $this->CI->input->post('key', TRUE);
            $page = $this->CI->input->post('page', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare the false response
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('wmarketing_no_promotional_messages_found')
                );

                // Display the false response
                echo json_encode($data);
                
            } else {

                // If $page is false, set 1
                if (!$page) {
                    $page = 1;
                }

                // Set the limit
                $limit = 10;
                $page--;

                // Use the base model for a simply sql query
                $get_messages = $this->CI->base_model->get_data_where(
                    'whatsapp_promotional',
                    'message_id, name',
                    array(
                        'user_id' => $this->CI->user_id
                    ),
                    array(),
                    array('name' => $this->CI->db->escape_like_str($key)),
                    array(),
                    array(
                        'order' => array('message_id', 'desc'),
                        'start' => ($page * $limit),
                        'limit' => $limit
                    )
                );

                // Verify if messages exists
                if ( $get_messages ) {

                    // Get total number of messages with base model
                    $total = $this->CI->base_model->get_data_where(
                        'whatsapp_promotional',
                        'COUNT(message_id) AS total',
                        array(
                            'user_id' => $this->CI->user_id
                        ),
                        array(),
                        array('name' => $this->CI->db->escape_like_str($key)),
                        array(),
                        array()
                    );

                    // Prepare the response
                    $data = array(
                        'success' => TRUE,
                        'messages' => $get_messages,
                        'total' => $total[0]['total'],
                        'page' => ($page + 1)
                    );

                    // Display the response
                    echo json_encode($data);

                } else {

                    // Prepare the false response
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('wmarketing_no_promotional_messages_found')
                    );

                    // Display the false response
                    echo json_encode($data);

                }
                
            }
            
        }
        
    }

    /**
     * The public method get_subscribers_by_categories gets the number of subscribers by category
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function get_subscribers_by_categories()
    {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('categories', 'Categories', 'trim');

            // Get data
            $categories = $this->CI->input->post('categories', TRUE);

            // Verify if the submitted data is correct
            if ($this->CI->form_validation->run() !== false) {

                // Verify if categories exists
                if ($categories) {

                    // All categories array
                    $all_categories = array();

                    // List all categories
                    foreach ($categories as $category) {

                        // Category should be numeric
                        if (is_numeric($category)) {

                            // Use the base model to verify if user has this category
                            $get_category = $this->CI->base_model->get_data_where(
                                'chatbot_categories',
                                'category_id',
                                array(
                                    'category_id' => $category,
                                    'user_id' => $this->CI->user_id
                                )
                            );

                            // Verify if category exists
                            if ($get_category) {

                                // Add category to list
                                $all_categories[] = $category;
                            }

                        }
                        
                    }

                    // Use the base model to get subscribers based on categories
                    $get_subscribers = $this->CI->wmarketing_subscribers_model->get_subscribers_by_categories($all_categories);

                    // Verify if subcribers were found
                    if ( $get_subscribers ) {

                        // Prepare success response
                        $data = array(
                            'success' => TRUE,
                            'message' => $get_subscribers .  $this->CI->lang->line('wmarketing_subscribers_found')
                        );

                        // Display success response
                        echo json_encode($data);
                        exit();                      

                    }
                    
                }

            }

        }

        // Prepare error response
        $data = array(
            'success' => FALSE,
            'message' => '0' .  $this->CI->lang->line('wmarketing_subscribers_found')
        );

        // Display error response
        echo json_encode($data);

    }

    /**
     * The public method delete_promotional_messages deletes promotional messages
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */ 
    public function delete_promotional_messages() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('promotional_messages', 'promotional messages', 'trim');
            
            // Get data
            $promotional_messages = $this->CI->input->post('promotional_messages');

            // Verify if request is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Default count
                $count = 0;

                // List all promotional messages
                foreach ( $promotional_messages as $promotional_message ) {

                    // Verify if the promotional message's id is numeric
                    if (is_numeric($promotional_message[1])) {

                        // Try to delete the promotional
                        if ( $this->CI->base_model->delete('whatsapp_promotional', array('message_id' => $promotional_message[1], 'user_id' => $this->CI->user_id)) ) {

                            // Try to delete the promotional's message
                            $this->CI->base_model->delete('whatsapp_promotional_message', array('message_id' => $promotional_message[1]) );

                            // Try to delete the promotional's categories
                            $this->CI->base_model->delete('whatsapp_promotional_categories', array('message_id' => $promotional_message[1]) );

                            // Try to delete the promotional's history
                            $this->CI->base_model->delete('whatsapp_promotional_history', array('message_id' => $promotional_message[1]) );                            

                            // Increase count
                            $count++;

                        }

                    }

                }

                if ( $count ) {

                    $data = array(
                        'success' => TRUE,
                        'message' => $count . $this->CI->lang->line('wmarketing_promotional_messages_were_deleted')
                    );

                    echo json_encode($data);

                } else {

                    $data = array(
                        'success' => FALSE,
                        'message' => '0' . $this->CI->lang->line('wmarketing_promotional_messages_were_deleted')
                    );

                    echo json_encode($data);

                }
                
                exit();
                
            }
            
        }
        
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('wmarketing_error_occurred')
        );

        echo json_encode($data);
        
    }

    /**
     * The public method send_promotional_messages sends promotional messages
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function send_promotional_messages() {

        // Get one scheduled message
        $scheduled_message = $this->CI->wmarketing_promotional_model->get_scheduled_message();

        // Verify if the scheduled's message exists
        if ( $scheduled_message ) {

            // Update the status
            $this->CI->base_model->update('whatsapp_promotional', array(
                'message_id' => $scheduled_message[0]['message_id']
            ), array(
                'status' => 1
            ));

            // Get the message's subscribers
            $get_subscribers = $this->CI->wmarketing_promotional_model->get_subscribers_by_message($scheduled_message[0]['message_id']);

            // Verify if subscribers exists
            if ( $get_subscribers ) {

                // List all subscribers
                foreach ( $get_subscribers as $get_subscriber ) {

                    // Prepare the url
                    $url = 'https://api.twilio.com/2010-04-01/Accounts/' . $get_subscriber['token'] . '/Messages.json';

                    // Set the params
                    $params = array(
                        'To' => 'whatsapp:' . $get_subscriber['name'],
                        'From' => 'whatsapp:' . $get_subscriber['user_name'],
                        'Body' => $scheduled_message[0]['body']
                    );

                    // Request for phone numbers
                    $curl = curl_init();
                    curl_setopt($curl, CURLOPT_URL, $url);
                    curl_setopt($curl, CURLOPT_TIMEOUT, 30);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($curl, CURLOPT_POST, 1);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
                    curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
                    curl_setopt($curl, CURLOPT_USERPWD, $get_subscriber['token'] . ':' . $get_subscriber['secret']);
                    $response = json_decode(curl_exec($curl), true);
                    curl_close($curl);

                    // Verify if response wasn't sent successfully
                    if ( isset($response['message']) ) {

                        // Save the error
                        $history = array(
                            'user_id' => $get_subscriber['user_id'],
                            'page_id' => $get_subscriber['network_id'],
                            'message_id' => $scheduled_message[0]['message_id'],
                            'subscriber_id' => $get_subscriber['subscriber_id'],
                            'body' => $scheduled_message[0]['body'],
                            'error' =>$this->CI->security->xss_clean($response['message']),
                            'type' => $scheduled_message[0]['type'],
                            'status' => 0,
                            'created' => time()
                        );

                        // Save subscriber's history
                        $this->CI->base_model->insert('whatsapp_promotional_history', $history);

                    } else {

                        // Save the error
                        $history = array(
                            'user_id' => $get_subscriber['user_id'],
                            'page_id' => $get_subscriber['network_id'],
                            'message_id' => $scheduled_message[0]['message_id'],
                            'subscriber_id' => $get_subscriber['subscriber_id'],
                            'body' => $scheduled_message[0]['body'],
                            'type' => $scheduled_message[0]['type'],
                            'status' => 1,
                            'created' => time()
                        );

                        // Save subscriber's history
                        $this->CI->base_model->insert('whatsapp_promotional_history', $history);
                        
                    }

                }

            }

        }
        
    }

}

/* End of file promotional.php */